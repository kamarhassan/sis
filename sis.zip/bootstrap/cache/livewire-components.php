<?php return array (
  'services.servicesclient' => 'App\\Http\\Controllers\\Admin\\Livewire\\Services\\Servicesclient',
  'students.registration' => 'App\\Http\\Controllers\\Admin\\Livewire\\Students\\Registration',
);