<?php

namespace App\Repository\Payment;

use App\Models\Payment;

class PaymentRepository implements PaymentInterface
{
   
}
