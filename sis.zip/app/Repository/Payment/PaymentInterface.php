<?php

namespace App\Repository\Payment;

interface PaymentInterface
{
   
}
