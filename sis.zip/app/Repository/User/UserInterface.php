<?php

namespace App\Repository\User;

interface UserInterface
{
    public function get_user_by_id($user_id);
}
