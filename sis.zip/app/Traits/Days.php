<?php

namespace App\Traits;

trait Days
{

}
