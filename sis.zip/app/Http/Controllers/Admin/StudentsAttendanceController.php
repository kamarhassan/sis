<?php

namespace App\Http\Controllers\Admin;

use App\Models\Admin;
use App\Models\Cours;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Repository\Admin\AdminInterface;
use App\Repository\Cours\CoursInterface;
use App\Repository\Students\StudentsInterface;

class StudentsAttendanceController extends Controller
{
    protected $coursrepos;
    protected $adminrepos;
    protected $studentsrepos;
    public function __construct(CoursInterface $coursinterface, AdminInterface $admininterfcae, StudentsInterface $stdinterface)
    {
        $this->coursrepos = $coursinterface;
        $this->adminrepos = $admininterfcae;
        $this->studentsrepos = $stdinterface;
    }

    public function index()
    {

        $admin_logged = Admin::find(Auth::id());
        // $this->adminrepos->all_teacher_id();
        if (!$admin_logged->hasRole('super admin'))
            $cours = $this->coursrepos->cours_of_teacher($admin_logged->id);
        else  $cours = $this->coursrepos->cours_of_teacher($this->adminrepos->all_teacher_id());
        // return $cours[0]['grade'];
        return view('admin.students-attendance.index', compact('cours'));
    }



    public function  attendance_general_info($cours_id)
    {
        $teacher_id = Admin::find(Auth::id());
        $cours = Cours::find($cours_id);
        if ($cours->teacher['id'] !=  $teacher_id['id']) {
            toastr()->error(__('site.this cours is not for you'));
            return redirect()->route('admin.take.attendance.students');
        }
        // $std =$this->studentsrepos->students_for_cours_defined($cours_id);
        return view('admin.students-attendance.students-for-cours',compact('cours'));
    }
}
