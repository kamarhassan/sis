
<?php $__env->startSection('content'); ?>
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a
                                    href="<?php echo e(route('admin.dashborad')); ?>"><?php echo app('translator')->get('site.Dashboard'); ?> </a>
                        </li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.cours.all')); ?>"> <?php echo app('translator')->get('site.cours'); ?> </a>
                        </li>
                        <li class="breadcrumb-item active">
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content-body">
        <!-- Basic form layout section start -->
        <section id="basic-form-layouts">
            <div class="row match-height">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title" id="basic-layout-form"> <?php echo app('translator')->get('site.add new cours'); ?> </h4>
                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>

                        </div>
                        
                        
                        <div class="card-content collapse show">
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('admin.cours.store')); ?>" class="form"
                                      enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class=" col-12">
                                        <div class="box bl-3.border-primary">
                                            <div class="box-header with-border">
                                                <h4 class="box-title"><strong><?php echo app('translator')->get('site.cours info'); ?></strong></h4>
                                                <ul class="box-controls pull-right">
                                                    
                                                    <li><a class="box-btn-slide" href="#"></a></li>
                                                    
                                                </ul>
                                            </div>

                                            <div class="box-body">
                                                <div class="form-body">
                                                    
                                                    
                                                    <div class="row">
                                                        <?php if(isset($grade)): ?>
                                                            <div class="col-md-6">
                                                                <div class="form-group">

                                                                    <div class="form-group">
                                                                        <label><?php echo app('translator')->get('site.cours'); ?> </label>
                                                                        <select name="grade"
                                                                                class="form-control select2"
                                                                                style="width: 100%;">

                                                                            <?php if(old('grade') != ''): ?>
                                                                                <option selected="selected"
                                                                                        value="<?php echo e(old('grade')); ?>">
                                                                                    <?php echo e(old('grade')); ?></option>
                                                                            <?php else: ?>
                                                                                <option selected="selected"
                                                                                        value=" <?php echo app('translator')->get('site.chosse the cours'); ?>">
                                                                                    <?php echo app('translator')->get('site.chosse the cours'); ?></option>
                                                                            <?php endif; ?>
                                                                            <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grades): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($grades->grade); ?>">
                                                                                    <?php echo e($grades->grade); ?>

                                                                                </option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        <?php endif; ?>
                                                        <?php if(isset($level)): ?>
                                                            <div class="col-md-6">
                                                                <div class="form-group">

                                                                    <div class="form-group">
                                                                        <label><?php echo app('translator')->get('site.level'); ?> </label>
                                                                        <select name="level"
                                                                                class="form-control select2"
                                                                                style="width: 100%;">
                                                                            <?php if(old('level') != ''): ?>
                                                                                <option selected="selected"
                                                                                        value="<?php echo e(old('level')); ?>">
                                                                                    <?php echo e(old('level')); ?></option>
                                                                            <?php else: ?>
                                                                                <option selected="selected"
                                                                                        value=" <?php echo app('translator')->get('site.chosse the cours'); ?>">
                                                                                    <?php echo app('translator')->get('site.chosse the cours'); ?></option>
                                                                            <?php endif; ?>
                                                                            <?php $__currentLoopData = $level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $levels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($levels->level); ?>">
                                                                                    <?php echo e($levels->level); ?>

                                                                                </option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label><?php echo app('translator')->get('site.start date'); ?> </label>
                                                                <input name="start_date" class="form-control"
                                                                       type="date"
                                                                       value="<?php echo e(old('start_date')); ?>"
                                                                       id="example-date-input">
                                                                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label><?php echo app('translator')->get('site.end date'); ?> </label>
                                                                <input name="end_date" class="form-control" type="date"
                                                                       value="<?php echo e(old('end_date')); ?>"
                                                                       id="example-date-input">
                                                                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label><?php echo app('translator')->get('site.start time'); ?> </label>
                                                                <input name="start_time" class="form-control"
                                                                       type="time"
                                                                       value="<?php echo e(old('start_time')); ?>"
                                                                       id="example-date-input">
                                                                <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label><?php echo app('translator')->get('site.end time'); ?> </label>
                                                                <input name="end_time" class="form-control" type="time"
                                                                       value="<?php echo e(old('end_time')); ?>"
                                                                       id="example-date-input">
                                                                <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label><?php echo app('translator')->get('site.actually start date'); ?> </label>
                                                                <input name="ac_start_date" class="form-control"
                                                                       type="date" value="<?php echo e(old('ac_start_date')); ?>"
                                                                       id="example-date-input">
                                                                <?php $__errorArgs = ['ac_start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label><?php echo app('translator')->get('site.actually end date'); ?> </label>
                                                                <input name="ac_end_date" class="form-control"
                                                                       type="date"
                                                                       value="<?php echo e(old('ac_end_date')); ?>"
                                                                       id="example-date-input">
                                                                <?php $__errorArgs = ['ac_end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label><?php echo app('translator')->get('site.max number of students'); ?> </label>
                                                                <input name="max_std_number" class="form-control"
                                                                       type="number" value="<?php echo e(old('max_std_number')); ?>"
                                                                       id="example-date-input">
                                                                <?php $__errorArgs = ['max_std_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <?php if(isset($status_od_cours)): ?>
                                                                    <label><?php echo app('translator')->get('site.status of cours'); ?> </label>
                                                                    <select name="status" class="form-control"
                                                                            style="width: 100%;">
                                                                        <?php if(old('status') != ''): ?>
                                                                            <option selected="selected"
                                                                                    value="<?php echo e(old('status')); ?>">
                                                                                <?php echo e(old('status')); ?></option>
                                                                        <?php else: ?>
                                                                            <option selected="selected"
                                                                                    value=" <?php echo app('translator')->get('site.chosse the cours'); ?>">
                                                                                <?php echo app('translator')->get('site.chosse the cours'); ?></option>
                                                                        <?php endif; ?>
                                                                        <?php $__currentLoopData = $status_od_cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_od_cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($status_od_cour->name); ?>">
                                                                                <?php echo e($status_od_cour->name); ?>

                                                                            </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <?php if(isset($teacher)): ?>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <div class="form-group">
                                                                        <label><?php echo app('translator')->get('site.teacher name'); ?> </label>
                                                                        <select name="teacher_name"
                                                                                class="form-control select2"
                                                                                style="width: 100%;">

                                                                            <?php if(old('teacher_name') != ''): ?>
                                                                                <option selected="selected"
                                                                                        value="<?php echo e(old('teacher_name')); ?>">
                                                                                    <?php echo e(old('teacher_name')); ?></option>
                                                                            <?php else: ?>
                                                                                <option selected="selected"
                                                                                        value=" <?php echo app('translator')->get('site.chosse the teacher name'); ?>">
                                                                                    <?php echo app('translator')->get('site.chosse the cours'); ?></option>
                                                                            <?php endif; ?>
                                                                            <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teachers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($teachers->name); ?>">
                                                                                    <?php echo e($teachers->name); ?>

                                                                                </option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <?php $__errorArgs = ['teacher_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        <?php endif; ?>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label><?php echo app('translator')->get('site.teacher fee'); ?> </label>
                                                                <input name="teacher_fee" class="form-control"
                                                                       type="number" step="any"
                                                                       value="<?php echo e(old('teacher_fee')); ?>"
                                                                       id="example-date-input">
                                                                <?php $__errorArgs = ['teacher_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        

                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label><?php echo app('translator')->get('site.level'); ?> </label>
                                                                <select name="days[]" multiple
                                                                        class="form-control select2"
                                                                        style="width: 100%;">

                                                                    <?php $__currentLoopData = days_of_week(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $days): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option selected value=<?php echo e($key); ?>>
                                                                            <?php echo e($days); ?>

                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <?php $__errorArgs = ['days[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label><?php echo app('translator')->get('site.description'); ?> </label>
                                                                <textarea name="description" id="description"
                                                                          class="form-control"></textarea>
                                                            </div>
                                                        </div>
                                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                                
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div>


                        
                        <div class=" col-12">
                            <div class="box ">
                                <div class="box-header with-border">
                                    <h4 class="box-title"><strong><?php echo app('translator')->get('site.cours fees'); ?></strong></h4>

                                    <ul class="box-controls pull-right">

                                        
                                        <li><a class="box-btn-slide" href="#"></a></li>
                                        
                                    </ul>
                                </div>
                                <div class="box-body">
                                    <div class="row">

                                        <?php if(isset($grade)): ?>
                                            <div class="col-md-6">
                                                <div class="form-group">

                                                    <div class="form-group">
                                                        <label><?php echo app('translator')->get('site.cours currency'); ?> </label>
                                                        <select name="cours_currency" class="form-control select2"
                                                                style="width: 100%;">
                                                            <?php $__currentLoopData = $cours_currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cours_currencys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($cours_currencys->id); ?>">
                                                                    <?php echo e($cours_currencys->symbol); ?>

                                                                    <- <?php echo e($cours_currencys->currency); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <?php $__errorArgs = ['cours_currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        <?php endif; ?>


                                    </div>

                                    <?php if(isset($fee_type)): ?>
                                        <div class="table-responsive">
                                            <table class="table table-hover ">
                                                <tr>
                                                    <th><?php echo app('translator')->get('site.select fee'); ?></th>
                                                    <th><?php echo app('translator')->get('site.fee value'); ?></th>
                                                </tr>
                                                <?php $__currentLoopData = $fee_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $feeType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <div class="demo-checkbox">
                                                                <input type="checkbox" name="fee[<?php echo e($feeType->id); ?>]"
                                                                       id="md_checkbox_<?php echo e($feeType->id); ?>"
                                                                       class="chk-col-primary"
                                                                       <?php if($feeType->sponsored == 1): ?>
                                                                       checked
                                                                       <?php endif; ?>
                                                                       onchange='total_coust(<?php echo json_encode($fee_type_id, 15, 512) ?>);'/>
                                                                <label for="md_checkbox_<?php echo e($feeType->id); ?>"><?php echo e($feeType->fee); ?></label>
                                                                
                                                                <?php $__errorArgs = ['fee.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                
                                                                
                                                            </div>
                                                        </td>
                                                        
                                                        <td>

                                                            <input
                                                                    class="form-control fee" type="number" step="any"

                                                                    id="fee_value_<?php echo e($feeType->id); ?>"
                                                                    onchange='total_coust(<?php echo json_encode($fee_type_id, 15, 512) ?>);'/>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                
                                                <tr>
                                                    <td>
                                                        <div>
                                                            <label for="total_coust"
                                                                   id="total_coust"><?php echo app('translator')->get('site.total_coust'); ?></label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div>
                                                            <label for="total_coust" id="total_coust_fee">0</label>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        


                        <div class="form-actions">
                            <button class="btn btn-close btn-danger btn-round fa fa-times" onclick="history.back();">
                                <i class="ft-x"></i><?php echo app('translator')->get('site.back'); ?>
                            </button>


                            <button type="submit" class="btn btn-close btn-success btn-round fa fa-save">

                                <i class="ft-x"></i> <?php echo app('translator')->get('site.save'); ?>
                            </button>


                        </div>
                        </form>
                    </div>
                </div>
            </div>
    </div>
    </div>
    </section>
    <!-- // Basic form layout section end -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
    </script>
    <script src="<?php echo e(URL::asset('assets/custome_js/cours_.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/select2/dist/js/select2.full.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/bootstrap-select/dist/js/bootstrap-select.js')); ?>">
    </script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/advanced-form-element.js')); ?>"></script>
    
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/cours/create.blade.php ENDPATH**/ ?>