<div class="box" id="spinner_loading">
    <div class="d-flex justify-content-center text-primary">
        <div class="spinner-border" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
</div>

<div class="box" id="services-table-" hidden>
    
    <div class="box-body">
        <div class="table-responsive ">
            <table id="services-table" class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo app('translator')->get('site.services'); ?></th>
                        <th><?php echo app('translator')->get('site.fee amount'); ?></th>
                        <th><?php echo app('translator')->get('site.currency name'); ?></th>
                        
                        <th><?php echo app('translator')->get('site.options'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($services)): ?>

                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $servicess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="Row<?php echo e($servicess['id']); ?> " id="Row<?php echo e($servicess['id']); ?> ">
                                <td><?php echo e($key + 1); ?>


                                </td>
                                <td><?php echo e($servicess['service']); ?>

                                    <div class="box-body ribbon-box">
                                        <?php if($servicess->active == 1): ?>
                                            <div class="ribbon-two ribbon-two-success">
                                                <span><?php echo e($servicess->getactive()); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="ribbon-two ribbon-two-danger">
                                                <span><?php echo e($servicess->getactive()); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>

                                <td><?php echo e($servicess['fee']); ?></td>
                                <td><?php echo e($servicess['currency']['currency']); ?> - <?php echo e($servicess['currency']['abbr']); ?> -
                                    <?php echo e($servicess['currency']['symbol']); ?></td>
                                <td>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit setting services')): ?>
                                        <ul>
                                            <li class="list-unstyled">
                                                <a class="btn text-success fa fa-pencil hover  hover-primary"
                                                    onclick="get_service('<?php echo e(route('admin.services.to-update', $servicess['id'])); ?>','<?php echo e(csrf_token()); ?>');"
                                                    title="<?php echo app('translator')->get('site.edit'); ?>">
                                                </a>
                                            </li>
                                        </ul>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete setting services')): ?>
                                        <a class="btn text-danger  glyphicon glyphicon-trash hover  hover-primary"
                                            title="<?php echo app('translator')->get('site.delete'); ?>"
                                            onclick="delete_by_id('<?php echo e(route('admin.services.delete')); ?>',<?php echo e($servicess['id']); ?>,'<?php echo e(csrf_token()); ?>','<?php echo e(json_encode(swal_fire_msg())); ?>');">
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($services->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/services/services/services-data.blade.php ENDPATH**/ ?>