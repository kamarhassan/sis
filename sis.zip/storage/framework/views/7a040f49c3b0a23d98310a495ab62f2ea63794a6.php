
    <div class="modal bs-examplemodal-lg  center-modal  modal-primary" id="modal-center" tabindex="-1" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
                
                <a type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <div class="modal-body">

                <p id="cours_details"><?php echo app('translator')->get('site.please wait to load cours'); ?></p>
            </div>
            
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/payment/cours_std.blade.php ENDPATH**/ ?>