
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .loader {
            left: 50%;
            margin-left: -4em;
        }

    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="box" id="spinner_loading">
        <div class="d-flex justify-content-center text-primary" >
            <div class="spinner-border" role="status">
              <span class="sr-only">Loading...</span>
            </div>
          </div>
    </div>

    <div class="box" id="table_std" hidden>

        
        <div class="box-body">
            <div class="table-responsive ">
                
                <table id="example1" class="table table-hover">
                    <thead>

                        <tr>
                          
                            <th><?php echo app('translator')->get('site.student name'); ?></th>
                            
                            <th><?php echo app('translator')->get('site.E-mail'); ?></th>
                            
                            <th><?php echo app('translator')->get('site.nbumber of cours'); ?></th>
                            <th><?php echo app('translator')->get('site.students photo'); ?></th>
                            <th><?php echo app('translator')->get('site.options'); ?></th>
                        </tr>

                    </thead>
                    <tbody>
                        <?php if(isset($std_registartion)): ?>
                            <?php $__currentLoopData = $std_registartion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stduents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="Row<?php echo e($stduents->user_id); ?>" class="bg-light mb-10 p-10 cursor_pointer hover-success">
                                   
                                    <td class="col-sm-2"><?php echo e($stduents['student'][0]['name']); ?> # <?php echo e($stduents->user_id); ?></td>
                                    
                                    <td class="col-md-3"><?php echo e($stduents['student'][0]['email']); ?></td>
                                    <td class="col-md-3"><?php echo e($stduents->total); ?></td>
                                    <td class="col-md-3">
                                        <img class="avatar avatar-xl avatar-1"  alt="">
                                    </td>
                                    <td>
                                        <ul>
                                            <li class="list-unstyled">
                                                <a data-toggle="modal" data-target="#modal-center"
                                                    onclick="get_cours_of_std(<?php echo e($stduents->user_id); ?>,'<?php echo e(route('admin.students.get_cours_std', $stduents->user_id)); ?>','<?php echo e(csrf_token()); ?>');"
                                                    class="btn fa fa-credit-card hover-warning text-light"
                                                    title="<?php echo app('translator')->get('site.save'); ?>"> <?php echo app('translator')->get('site.pay'); ?></a>
                                            </li>

                                        </ul>
                                        

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>




    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.payment.cours_std', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('script'); ?>
    <script>

        $(document).ready(function() {
            $('#spinner_loading').css("display", "none");

            $('#table_std').removeAttr('hidden');

            var table = $('#example1').DataTable({
                scrollY: "400px",
                // scrollX: true,
                scrollCollapse: true,
                paging: false,
                responsive: true,
                // ajax: '/test/0',

            });
        });
    </script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/fixed_column_datatable.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\custome_js\get_cours_cours_std.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/payment/index.blade.php ENDPATH**/ ?>