



<?php $__env->startSection('content'); ?>

    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"></h3>
        </div>

        <div class="box-body">
            <div class="table-responsive">
                <table id="example1" class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo app('translator')->get('site.cours'); ?> </th>
                            <th><?php echo app('translator')->get('site.status'); ?> </th>
                            <th><?php echo app('translator')->get('site.teacher name'); ?> </th>
                            <th><?php echo app('translator')->get('site.actually start date'); ?> </th>
                            <th><?php echo app('translator')->get('site.start time'); ?> </th>
                            <th><?php echo app('translator')->get('site.actually end date'); ?> </th>
                            <th><?php echo app('translator')->get('site.end time'); ?> </th>
                            <th><?php echo app('translator')->get('site.std count'); ?> </th>
                            <th><?php echo app('translator')->get('site.options'); ?> </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($cours)): ?>
                            <?php $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="Row<?php echo e($cour->id); ?> " class="hover-success">
                                    <td onclick='test();'> <?php echo e($key); ?></td>
                                    <td><?php echo e($cour->grade); ?>, <?php echo e($cour->level); ?> </td>
                                    <td> <?php echo e($cour->status); ?> </td>
                                    <td> <?php echo e($cour->name); ?> </td>
                                    <td> <?php echo e($cour->act_StartDa); ?> </td>
                                    <td> <?php echo e($cour->startTime); ?> </td>
                                    <td> <?php echo e($cour->act_EndDa); ?> </td>
                                    <td> <?php echo e($cour->endTime); ?> </td>
                                    <td>add students count</td>
                                    
                                    <td>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit cours')): ?>
                                            <a href="<?php echo e(route('admin.cours.edit', $cour->id)); ?>" 
                                                class="btn fa fa-edit" title="<?php echo app('translator')->get('site.edit'); ?>"">

                                            </a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete cours')): ?>
                                            <a token="<?php echo e(csrf_token()); ?>" class="btn  glyphicon glyphicon-trash hover-danger"
                                                title="<?php echo app('translator')->get('site.delete'); ?>" onclick="">
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>


                    </tbody>

                </table>
            </div>
        </div>

    </div>






    <script>
        var config = {
            routes: {
                delete: "<?php echo e(route('admin.language.delete')); ?>"
            }
        };
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#example1').DataTable({
                // "order": [ 0, 'asc' ]
                "order": ['0', 'desc'] // nb four is column status,
                responsive: true,
            });
        });
    </script>
    <script src="<?php echo e(URL::asset('assets/custome_js/cours_.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/cours/index.blade.php ENDPATH**/ ?>