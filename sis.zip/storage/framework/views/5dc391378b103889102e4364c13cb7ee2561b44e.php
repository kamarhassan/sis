

<?php $__env->startSection('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

    <!-- Basic Forms -->
    <div class="box">
        <div class="box-header with-border">
            <h4 class="box-title"><?php echo app('translator')->get('site.add new level'); ?></h4>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <div class="row">
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create levels')): ?> 
                 <div class="col-12 col-lg-5 col-xl-6">
                     <form method="post" action="<?php echo e(route('admin.level.store')); ?>">
                         <?php echo csrf_field(); ?>
                         <div class="row">
                             <div class="col-12">
                                 <div class="add_item">
                                     <div class="row">
                                         <div class="col-md-5">
                                             <div class="form-group">
                                                 <h5><?php echo app('translator')->get('site.levels'); ?> <span class="text-danger">*</span></h5>
                                                 <div class="controls">
                                                     <input type="text" name="level[]" class="form-control">
                                                 </div>
                                             </div>
                                             <?php $__errorArgs = ['levelss[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                 <span class="text-danger"><?php echo e($message); ?> </span>
                                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                         </div><!-- End col-md-5 -->
                                         <div class="col-md-2" style="padding-top: 25px;">
                                             <span class="btn btn-success addeventmore"><i class="fa fa-plus-circle"></i>
                                             </span>
                                         </div><!-- End col-md-5 -->
                                     </div> <!-- end Row -->
                                 </div> <!-- // End add_item -->
                                 <div class="text-xs-right">
                                     <input type="submit" class="btn btn-rounded btn-info mb-5" value="<?php echo app('translator')->get('site.save'); ?>">
                                 </div>
                             </div>
                         </div>
                     </form>
                 </div>
               <?php endif; ?>
        
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit levels','delete levels'])): ?> 
                   <div class="col-12 col-lg-5 col-xl-6">
                        <div class="table-responsive">
                            <table id="example1" class="table  table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo app('translator')->get('site.level'); ?> </th>
                                        <th><?php echo app('translator')->get('site.options'); ?> </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($level)): ?>
                                        <?php $__currentLoopData = $level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $levels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <tr class="Row<?php echo e($levels->id); ?> " id="Row<?php echo e($levels->id); ?> ">
    
                                                <?php echo csrf_field(); ?>
                                                <td> <?php echo e($key + 1); ?> </td>
                                                <td>
                                                    <label id="label_<?php echo e($levels->id); ?>">
                                                        <span> <?php echo e($levels->level); ?></span>
                                                    </label>
                                                </td>
                                                <td>
                                                   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit levels')): ?>  
                                                     <a token="<?php echo e(csrf_token()); ?>"
                                                         onclick="change_to_update_level(<?php echo e($levels->id); ?>,'<?php echo e($levels->level); ?>','<?php echo e(route('admin.level.update')); ?>', '<?php echo e(csrf_token()); ?>');"
                                                         class="btn fa fa-edit" title="<?php echo app('translator')->get('site.edit'); ?>"
                                                         id="btn_editable_<?php echo e($levels->id); ?>">
                                                         
                                                     </a>
                                                   <?php endif; ?>
                                                
                                                   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete levels')): ?> 
                                                     <a token="<?php echo e(csrf_token()); ?>" class="btn  glyphicon glyphicon-trash"
                                                         title="<?php echo app('translator')->get('site.delete'); ?>"
                                                         onclick="delete_by_id('<?php echo e(route('admin.level.delet')); ?>',<?php echo e($levels->id); ?>,'<?php echo e(csrf_token()); ?>','<?php echo e(json_encode(swal_fire_msg())); ?>');">
     
     
                                                     </a>
                                                   <?php endif; ?>
                                                    
    
                                                </td>
    
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
    
    
                                </tbody>
    
                            </table>
                        </div>
    
                    </div>
    
                </div>
            <?php endif; ?>
            <!-- /.row -->
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->




    <div style="visibility: hidden;">

        <div class="whole_extra_item_add" id="whole_extra_item_add">
            <div class="delete_whole_extra_item_add" id="delete_whole_extra_item_add">
                <div class="form-row">
                    <div class="col-md-5">
                        <div class="form-group">
                            <h5><?php echo app('translator')->get('site.grade'); ?> <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text" id="grade" name="level[]" class="form-control">
                            </div>
                        </div>
                        <?php $__errorArgs = ['grades[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div><!-- End col-md-5 -->
                    <div class="col-md-2" style="padding-top: 25px;">
                        <span class="btn btn-success addeventmore"><i class="fa fa-plus-circle"></i> </span>
                        <span class="btn btn-danger removeeventmore"><i class="fa fa-minus-circle"></i> </span>
                    </div><!-- End col-md-2 -->
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            var counter = 1;
            $(document).on("click", ".addeventmore", function() {
                // var field = document.getElementById("grade");// get element named grade from hidde form
                // field.id = "horse"; // using element properties
                // field.setAttribute("name", "grade["+counter+"]"); // rename grade to grade[index] to validate an array

                //  console.log()
                var whole_extra_item_add = $('#whole_extra_item_add').html();

                $(this).closest(".add_item").append(whole_extra_item_add);
                counter++;
            });
            $(document).on("click", '.removeeventmore', function(event) {
                $(this).closest(".delete_whole_extra_item_add").remove();
                counter -= 1
            });
            // var table = $('#example1').DataTable({

            //       responsive: true,

            //       // ajax: '/test/0',

            //   });
        });
    </script>

    <script src="<?php echo e(URL::asset('assets/custome_js/delete.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/custome_js/update.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/jquery-toast-plugin-master/src/jquery.toast.js')); ?>">
    </script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/setup/level/create.blade.php ENDPATH**/ ?>