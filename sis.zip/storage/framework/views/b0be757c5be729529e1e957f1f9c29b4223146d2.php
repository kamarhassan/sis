


<?php $__env->startSection('content'); ?>
    <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashborad')); ?>">الرئيسية </a>
                        </li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.language')); ?>"> أللغات </a>
                        </li>
                        <li class="breadcrumb-item active"><?php echo app('translator')->get('site.lang edit'); ?>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content-body">
        <!-- Basic form layout section start -->
        <section id="basic-form-layouts">
            <div class="row match-height">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title" id="basic-layout-form"> <?php echo app('translator')->get('site.lang edit'); ?> </h4>
                            
                        </div>

                        <div class="card-content collapse show">
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('admin.language.update', $language->id)); ?>"
                                    class="form" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                   <div class="form-body">
                                        <h4 class="form-section"><i class="ft-home"></i> <?php echo app('translator')->get('site.Language data'); ?> </h4>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="projectinput1"><?php echo app('translator')->get('site.enter lang'); ?></label>
                                                    <input type="text" name="name" value="<?php echo e($language->name); ?>"
                                                        id="name" class="form-control"
                                                        placeholder="<?php echo app('translator')->get('site.enter lang'); ?> " name="name">
                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>


                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="projectinput1"> <?php echo app('translator')->get('site.country'); ?> </label>
                                                    <input type="text" value="<?php echo e($language->country); ?>" id="country"
                                                        class="form-control" placeholder="<?php echo app('translator')->get('site.enter country'); ?> "
                                                        name="country">
                                                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?> </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="projectinput1"> <?php echo app('translator')->get('site.code'); ?> </label>
                                                    <input type="text" value="<?php echo e($language->code); ?>" id="code"
                                                        class="form-control" placeholder="<?php echo app('translator')->get('site.enter code'); ?> "
                                                        name="code">
                                                    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?> </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="projectinput2"> <?php echo app('translator')->get('site.direction'); ?> </label>
                                                    <select name="direction" class="select2 form-control">
                                                        


                                                        <option value="rtl"
                                                            <?php if($language->direction == 'rtl'): ?> selected <?php endif; ?>><?php echo app('translator')->get('site.from right to left'); ?></option>

                                                        <option value="ltr"
                                                            <?php if($language->direction == 'ltr'): ?> selected <?php endif; ?>><?php echo app('translator')->get('site.from left to right'); ?></option>


                                                        </optgroup>
                                                    </select>
                                                    <?php $__errorArgs = ['direction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group mt-1">
                                                    <div class="box-controls pull-right">
                                                        <label class="switch switch-border switch-success">
                                                            <input type="checkbox" value="1" name="active"
                                                                <?php if($language->active == 1): ?> checked <?php endif; ?> />
                                                            <span class="switch-indicator"></span>
                                                            <label for="switcheryColor4" class="card-title ml-1"><?php echo app('translator')->get('site.is active'); ?> </label>
                                                            <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="text-danger"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>


                            <div class="form-actions">
                                <button class="btn btn-close btn-danger btn-round fa fa-times" onclick="{history.back();}">
                                    <i class="ft-x"></i> <?php echo app('translator')->get('site.back'); ?>
                                </button>


                                <button type="submit" class="btn btn-close btn-success btn-round fa fa-save">

                                    <i class="ft-x"></i><?php echo app('translator')->get('site.save'); ?>
                                </button>


                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>
    <!-- // Basic form layout section end -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/language/edit.blade.php ENDPATH**/ ?>