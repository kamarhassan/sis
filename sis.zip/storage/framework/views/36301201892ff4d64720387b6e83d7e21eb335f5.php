<header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

        <h1 class="logo mr-auto"><a href="index.html"><span>AI</span>MS</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

        <nav class="nav-menu d-none d-lg-block">
            <ul>

                <li><a href="<?php echo e(route('web.index')); ?>">Home</a></li>
                <li><a href="">About us</a></li>


                <?php if(auth()->guard()->guest()): ?>
                    <li>
                        <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>
                        <li>
                            <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                <li><a href="<?php echo e(route('web.user.cours', Auth::user()->id )); ?>">Reserved cours</a></li>
                    <li class="drop-down"><a href=""><?php echo e(Auth::user()->name); ?></a>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                               document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?> </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </li>

                <?php endif; ?>


                

                

            </ul>
        </nav><!-- .nav-menu -->

        

    </div>
</header>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>