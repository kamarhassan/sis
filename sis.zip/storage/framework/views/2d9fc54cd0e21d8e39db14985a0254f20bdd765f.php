
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .overlayl {
            position: fixed;

            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 2;
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box">
        

        <div class="box-body">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['register order delete all', 'register order deny all', 'register order read all', 'register order
                aprrove all'])): ?>
                <div class="mailbox-controls">

                    <button type="button" class="btn btn-sm checkbox-toggle btn-outline" id="action_after_select"><i
                            class="ion ion-android-checkbox-outline-blank"></i>
                    </button>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('register order delete all')): ?>
                        <div class="btn-group">
                            <a type="button" class="btn btn-outline btn-sm hover-danger" title="<?php echo app('translator')->get('site.delete all'); ?>"
                                onclick="delete_notification_admin_selected('<?php echo e(route('admin.notification.delete.marked')); ?>','new_regitration_order','<?php echo e(csrf_token()); ?>','<?php echo e(json_encode(swal_fire_msg())); ?>');">
                                <i class="ion ion-trash-a"></i>
                            </a>
                        </div>
                    <?php endif; ?>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('register order read all')): ?>
                        <div class="btn-group">
                            <a type="button" class="btn btn-outline btn-sm hover-warning" title="<?php echo app('translator')->get('site.mark all as read'); ?>"
                                onclick="submit('<?php echo e(route('admin.notification.read.marked')); ?>','new_regitration_order');">
                                <i class="fa fa-envelope-open-o"></i>
                            </a>
                        </div>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('register order deny all')): ?>
                        <div class="btn-group">
                            <a type="button" class="btn btn-outline btn-sm hover-danger" title="<?php echo app('translator')->get('site.deny'); ?>"
                                onclick="submit('<?php echo e(route('admin.notification.deny.marked')); ?>','new_regitration_order');">
                                <i class="ti ti-close"></i>
                            </a>
                        </div>
                    <?php endif; ?>

                </div>
            <?php endif; ?>
            <div class="mailbox-messages">
                <div class="table-responsive">
                    <form id='new_regitration_order'>
                        <?php echo csrf_field(); ?>
                        <table class="table no-border" id="cours_fee_datatable">
                            <tbody>
                                <?php if(isset($new_order_registeration)): ?>
                                    <?php $__currentLoopData = $new_order_registeration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="Row<?php echo e($new_order['id']); ?>" id="Row<?php echo e($new_order['id']); ?>">
                                            <td><input type="checkbox" name="order_id[]" value="<?php echo e($new_order['id']); ?>">
                                            </td>
                                            <td class="w-80"><a><img class="avatar" src="../images/avatar/2.jpg"
                                                        alt="..."></a></td>
                                            <td>
                                                
                                                <a <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read only register order')): ?> 
                                                     onclick="get_user_info('<?php echo e(route('admin.notification.get.user.info', $new_order['id'])); ?>','<?php echo e(csrf_token()); ?>');"
                                                        
                                                <?php endif; ?>
                                                    class="mailbox-name hover-primary" data-toggle="modal"
                                                    data-target="#modal-center">
                                                    <?php echo e($new_order['user']['id']); ?> # <?php echo e($new_order['user']['name']); ?></a>
                                            </td>
                                            <td class="mailbox-subject">
                                                <?php echo e($new_order['cours_reserved']['grade']['grade']); ?> #
                                                <?php echo e($new_order['cours_reserved']['level']['level']); ?>

                                            </td>
                                            <td>
                                                <div class="box-body ribbon-box">
                                                    <?php if(is_null($new_order['status'])): ?>
                                                        <div class="ribbon ribbon-warning rounded20" id="pending">
                                                            <?php echo app('translator')->get('site.pending'); ?></div>
                                                    <?php elseif($new_order['status'] == 1): ?>
                                                        <div class="ribbon ribbon-success rounded20" id="approved">
                                                            <?php echo app('translator')->get('site.approved'); ?></div>
                                                    <?php elseif($new_order['status'] == 0): ?>
                                                        <div class="ribbon ribbon-danger rounded20" id="deny">
                                                            <?php echo app('translator')->get('site.deny'); ?></div>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="box-body ribbon-box">
                                                    <?php if($new_order['is_read'] == 0): ?>
                                                        <div class="ribbon ribbon-success  rounded20" id="read">
                                                            <?php echo app('translator')->get('site.read'); ?></div>
                                                    <?php else: ?>
                                                        <div class="ribbon ribbon-warning  rounded20" id="unread">
                                                            <?php echo app('translator')->get('site.unread'); ?></div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </form>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.notification.user-information', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('assets/custome_js/save.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/custome_js/delete.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_plugins/iCheck/icheck.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/vendor_components/perfect-scrollbar-master/perfect-scrollbar.jquery.min.js')); ?>">
    </script>

    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/mailbox.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/custome_js/get_info_user.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/notification/new-registration.blade.php ENDPATH**/ ?>