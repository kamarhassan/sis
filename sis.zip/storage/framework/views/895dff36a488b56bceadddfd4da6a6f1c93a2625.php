<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['reports', 'cours','view report'])): ?>
    
 
    <li class="treeview   <?php echo e($prefix == getprefix('reports') ? 'active' : ''); ?>     ">
        <a href="#">
            <i class="fa fa-user-circle"></i>
            <span><?php echo app('translator')->get('site.report'); ?></span>
            <span class="pull-right-container">
                <i class="fa fa-angle-right pull-right"></i>
            </span>
        </a>

        <ul class="treeview-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view report')): ?>
                <li><a href="<?php echo e(route('admin.report')); ?>">
                        <i class="ti-more">
                        </i>
                        <?php echo app('translator')->get('site.report'); ?>
                    </a>
                </li>
            <?php endif; ?>

        </ul>
    </li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/layouts/nav_bar_layouts/reports.blade.php ENDPATH**/ ?>