
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box bl-3 border-warning br-3">

        <div class="box-body">
            <div class="box-header with-border">
                <h3 class="box-title text-capitalize text-warning text-uppercase">
                </h3>
            </div>
            <div class="row show-grid">
                <div class="col-md-6">
                    <span>
                        <?php echo app('translator')->get('site.student name'); ?> : <span class="bb-1 border-success">
                            <?php echo e($students->name); ?>

                        </span>
                    </span>
                </div>
                <div class="col-md-6">
                    <span>
                        <?php echo app('translator')->get('site.cours info'); ?> : <span class="bb-1 border-success">
                            <?php if(isset($cours)): ?>
                                <?php echo e($cours['cours']['grade']['grade']); ?> - <?php echo e($cours['cours']['level']['level']); ?> -
                                <?php echo e($cours['cours']['teacher_name']['name']); ?>

                            <?php endif; ?>
                        </span>
                    </span>
                </div>
            </div> <!-- End of row show-grid cours info and std name -->
        </div>


        <div class="box">
            <div class="col-md-4">
                <input type="hidden">
                <h4 class=" bb-1  border-danger box-title text-capitalize  text-uppercase" style="color:rgb(255, 153, 0)">
                    <?php echo app('translator')->get('site.fee of this cours is'); ?>
                    <?php echo e($cours_currency['currency']); ?> - <?php echo e($cours_currency['abbr']); ?> - <?php echo e($cours_currency['symbol']); ?>

                </h4>
            </div>
            <form id="payment_data">
                <div class="box ">
                    <div class="row show-grid">
                        <div class="col-md-3">
                            <span>
                                <?php echo app('translator')->get('site.amount'); ?> :
                            </span>
                        </div>
                        <input type="hidden" name="cours_id" id="cours_id" value="<?php echo e(encrypt($cours['cours']['id'])); ?>">
                        <input type="hidden" name="user_id" id="user_id" value="<?php echo e(encrypt($students->id )); ?>">
                        <input type="hidden" name="receipt_id" id="receipt_id" value="<?php echo e($receipt['id']); ?>">
                        <input type="hidden" name="cours_currency_abbr" id="cours_currency_abbr"
                            value="<?php echo e($cours_currency['abbr']); ?>">
                        <input type="hidden" name="cours_currency_id" id="cours_currency_abbr"
                            value="<?php echo e($cours_currency['id']); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-6" id="normal_pament">
                            <input type="number" id="amount_to_paid" step="any" class='form-control'
                                placeholder="<?php echo app('translator')->get('site.paid fee here'); ?>" name="amount_to_paid" value="<?php echo e($receipt['amount']); ?>">
                            <span class="text-danger" id="amount_to_paid_"> </span>
                        </div>

                        <div class="col-md-6" id="Other_payment" hidden>
                            <div class="col-md-6" id="normal_pament">
                                <?php echo app('translator')->get('site.paid fee here'); ?>
                                <input type="number" id="other_amount_to_paid" step="any" class='form-control'
                                    placeholder="<?php echo app('translator')->get('site.paid fee here'); ?>" name="other_amount_to_paid"
                                    value="<?php echo e($receipt['other_amount']); ?>">
                                <span class="text-danger" id="other_amount_to_paid_"> </span>
                            </div>
                            <div class="col-md-6" id="normal_pament">
                                <?php echo app('translator')->get('site.rate exchange'); ?>
                                <input type="number" id="rate" step="any" class='form-control'
                                    placeholder="<?php echo app('translator')->get('site.rate'); ?>" name="rate"
                                    value="<?php echo e($receipt['rate_exchange']); ?>">
                                <span class="text-danger" id="rate_"> </span>
                            </div>
                            <div class="col-md-6" id="normal_pament">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('site.cours currency'); ?> </label>
                                    <select name="other_payment_currency" class="form-control select2" style="width: 100%;">
                                        <?php if(isset($currency_active)): ?>
                                            <?php $__currentLoopData = $currency_active; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cours_currencys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if( $cours_currency['id'] != $cours_currencys->id): ?>
                                                    <option value="<?php echo e($cours_currencys->id); ?>">
                                                        <?php echo e($cours_currencys->symbol); ?> <- <?php echo e($cours_currencys->currency); ?>

                                                            </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <span class="text-danger" id="cours_currency_"> </span>
                        </div>

                        <?php echo csrf_field(); ?>
                        <div class="col-md-2">
                            <div class="demo-checkbox">
                                <input type="checkbox" name="payment_methode" id="payment_methode" class="chk-col-success"
                                    onchange='change_payment_methode();' value="1" />
                                <label for="payment_methode"><?php echo app('translator')->get('site.other payment'); ?></label>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="box ">
                    <div class="row show-grid">
                        <div class="col-md-3">
                            <span>
                                <?php echo app('translator')->get('site.receipt description'); ?> :
                            </span>
                        </div>
                        <div class="col-md-6">
                            <input type="text" class='form-control' placeholder="<?php echo app('translator')->get('site.description'); ?>"
                                name="receipt_description" id="receipt_description"
                                value="<?php echo e($receipt['description']); ?>">
                            <span class="bb-1 border-success">
                        </div>
                    </div>
                </div>
                <div class="box ">
                    <div class="row show-grid">

                        <div class="col-md-3">
                            <span>
                                <?php echo app('translator')->get('site.payment type'); ?> <span class="bb-1 border-success">
                                </span>
                            </span>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <div class="radio">
                                    <input name="pay_type" type="radio" id="pay_cache_" checked
                                        onclick="change_pay_type(this.value);" value="pay_cache_">
                                    <label for="pay_cache_">cache</label>


                                    <input name="pay_type" type="radio" id="pay_check_"
                                        onclick="change_pay_type(this.value);" value="pay_check_">
                                    <label for="pay_check_">check</label>
                                    <span class="text-danger" id="pay_by_check_"> </span>
                                </div>
                            </div>
                        </div>

                        <div id="div_pay_check" hidden>

                            <div class="form-group row">
                                <label for="example-text-input" class="col-sm-1 col-form-label">#</label>
                                <div class="col-sm-10">
                                    <input class='form-control' id="check_number" type="number" step="any"
                                        placeholder="<?php echo app('translator')->get('site.Enter check number'); ?>" name="check_number" id="check_number"
                                        value="<?php echo e($receipt['checkNum']); ?>">
                                </div>
                                <span class="text-danger" id="check_number_"> </span>
                            </div>
                            <div class="form-group row">
                                <label for="example-text-input" class="col-sm-1 col-form-label">#</label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="bank" id="bank">
                                        <option></option>
                                        <option>slect from bank list 2</option>
                                        <option>slect from bank list3 </option>
                                        <option>slect from bank list 4</option>
                                        <option>slect from bank list 5</option>
                                    </select>
                                </div>
                            </div>
                            <span class="text-danger" id="bank_"> </span>
                        </div>
                    </div>
                </div>
            </form>
            <div class="col-md-12">
                <?php if(isset($payment)): ?>
                    
                    <div class="table-responsive">
                        <table id="payment_table" class="table table-hover mb-0">
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('site.fee type'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('site.fee value'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('site.registration date'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('site.paid'); ?></th>
                                
                                <th scope="col"><?php echo app('translator')->get('site.remaining'); ?></th>
                                
                            </tr>
                            <form id="alldata">

                                <?php if($payment->count() > 0): ?>
                                    <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feestopaid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td scope="row"> <?php echo e($feestopaid['cours_fee']['fee_type']['fee']); ?> </td>
                                            <td scope="row"> <?php echo e($feestopaid['cours_fee']['value']); ?> </td>
                                            <td scope="row"> <?php echo e($students['created_at']->format('d-m-Y')); ?> </td>
                                            <td scope="row"> <?php echo e($feestopaid['paid_amount']); ?> </td>
                                            <td scope="row"> <?php echo e($feestopaid['remaining']); ?> </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    
                                <?php endif; ?>
                            </form>
                            <tr scope="col" class="text-warning text-uppercase">
                                <td scope="row"><?php echo app('translator')->get('site.cours fee total'); ?> </td>

                                <td scope="row"><?php echo e($cours['cours_fee_total']); ?></td>
                                <td scope="row"> </td>
                                <td scope="row"> <?php echo e($cours['cours_fee_total'] -$cours['remaining']); ?></td>
                                <td scope="row"><?php echo e($cours['remaining']); ?></td>
                            </tr>
                        </table>
                    </div>
                <?php endif; ?>



                <div>
                    <div class="row">
                        <div class="col-md-3">
                            <button class="btn  glyphicon glyphicon-arrow-left hover-success " title="<?php echo app('translator')->get('site.save'); ?>"
                                type="submit"
                                onclick="savepayment('<?php echo e(route('admin.payment_edit_to_receipt')); ?>');">
                                <span class=""> <?php echo app('translator')->get('site.next step'); ?></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('assets/custome_js/payment_for_cours_and_services.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/select2/dist/js/select2.full.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/bootstrap-select/dist/js/bootstrap-select.js')); ?>">
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/payment/edit_payment.blade.php ENDPATH**/ ?>