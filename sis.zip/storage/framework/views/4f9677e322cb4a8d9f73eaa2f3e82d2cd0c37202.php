<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['cours',  'create cours', 'edit cours', 'delete cours'])): ?>
    <li class="treeview   <?php echo e($prefix == getprefix('cours') ? 'active' : ''); ?>     ">
        <a href="#">
            <i class="fa fa-book "></i>
            <span><?php echo app('translator')->get('site.cours'); ?></span>
            <span class="pull-right-container">
                <i class="fa fa-angle-right pull-right"></i>
            </span>
        </a>

        <ul class="treeview-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit cours', 'delete cours')): ?>
                <li><a href="<?php echo e(route('admin.cours.all')); ?>">
                        <i class="ti-more">
                        </i>
                        <?php echo app('translator')->get('site.all cours'); ?>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create cours')): ?>
                <li><a href="<?php echo e(route('admin.cours.add')); ?>">
                        <i class="ti-more">
                        </i>
                        <?php echo app('translator')->get('site.add new cours'); ?>
                    </a>
                </li>
            <?php endif; ?>


        </ul>
    </li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/layouts/nav_bar_layouts/cours.blade.php ENDPATH**/ ?>