
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.attendance students'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"></h3>
        </div>

        <div class="box-body">
            <div class="table-responsive">
                <table id="attendance" class="table table-hover">
                    <thead>

                        <tr>
                            <th>#</th>
                            <th><?php echo app('translator')->get('site.cours'); ?> </th>
                            
                            <th><?php echo app('translator')->get('site.status'); ?> </th>
                            <th><?php echo app('translator')->get('site.actually start date'); ?> </th>
                            <th><?php echo app('translator')->get('site.actually end date'); ?> </th>
                            <th><?php echo app('translator')->get('site.actually end date'); ?> </th>
                            <th><?php echo app('translator')->get('site.end time'); ?> </th>
                            <th><?php echo app('translator')->get('site.std count'); ?> </th>
                            <th><?php echo app('translator')->get('site.take attendance'); ?> </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($cours)): ?>
                            <?php $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="Row<?php echo e($cour['id']); ?> " class="hover-success">
                                    <td onclick='test();'> <?php echo e($cour['id']); ?></td>
                                    <td><?php echo e($cour['grade']); ?> # <?php echo e($cour['level']); ?></td>
                                    
                                    <td> <?php echo e($cour['status']); ?> </td>
                                    <td> <?php echo e($cour['act_StartDa']); ?> </td>
                                    <td> <?php echo e($cour['act_EndDa']); ?> </td>
                                    <td> <?php echo e($cour['startTime']); ?> </td>
                                    <td> <?php echo e($cour['endTime']); ?> </td>
                                    <td> <?php echo e($cour['count_std']); ?> </td>
                                    <td> <a href="<?php echo e(route('admin.attendance.general.info', $cour['id'])); ?>"
                                        class="btn text-warning glyphicon glyphicon-pencil  hover-primary" title="<?php echo app('translator')->get('site.print'); ?>">
                                    </a> </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        // $('#spinner_loading').css("display", "none");

        // $('#attendance').removeAttr('hidden');
        var table = $('#attendance').DataTable({
            order: [
                [0, 'desc']
            ],
            // scrollY: "400px",
            // scrollX: true,
            responsive: true,
            // scrollCollapse: true,
            paging: false,
            // ajax: '/test/0',

        });
    });
</script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/students-attendance/index.blade.php ENDPATH**/ ?>