
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .overlayl {
            position: fixed;

            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 2;
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="box-body" id="spinner_loading">
        <div class="d-flex justify-content-center text-primary ">
            <div class="spinner-border " role="status">

                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>


    
    <div class="box-body" id="table_std" hidden>
        <div class="table-responsive">
            <table id="example1" class="table table-hover">
                <thead>

                    <tr>
                        <th><?php echo app('translator')->get('site.id'); ?> #</th>
                        <th><?php echo app('translator')->get('site.Client name'); ?></th>
                        <th><?php echo app('translator')->get('site.services'); ?></th>

                        <th><?php echo app('translator')->get('site.amount'); ?></th>
                        
                        <th><?php echo app('translator')->get('site.payment date'); ?></th>
                        <th><?php echo app('translator')->get('site.options'); ?></th>
                        
                    </tr>

                </thead>
                <tbody>
                    <?php if(isset($service_repceit)): ?>
                        <?php $__currentLoopData = $service_repceit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_repceits): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="Row<?php echo e($service_repceits['id']); ?>" id="Row<?php echo e($service_repceits['id']); ?>">
                                <td><?php echo e($service_repceits['id']); ?></td>
                                <td>
                                   <span class="text-wrap"> <?php echo e($service_repceits['client']['id']); ?> # <?php echo e($service_repceits['client']['name']); ?></span>
                                </td>
                                <td class="text-wrap">

                                <?php if(isset($service_repceits['services_'])): ?>
                                        <?php echo e($service_repceits['services_']['service']); ?> #<br> <span class="text-wrap text-warning">
                                            <?php echo e($service_repceits['services_']['fee']); ?>

                                            <?php echo e($service_repceits['services_currency']['symbol']); ?> -
                                            <?php echo e($service_repceits['services_currency']['abbr']); ?></span>

                                <?php endif; ?>

                                </td>
                                <td><?php echo e($service_repceits['amount_total']); ?>  <span class="text-wrap text-warning">
                                        <?php echo e($service_repceits['services_currency']['symbol']); ?> -
                                        <?php echo e($service_repceits['services_currency']['abbr']); ?></span></td>
                                <td><?php echo e($service_repceits['created_at']->format('d-m-Y')); ?></td>
                                <td>
                                   
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit old services receipt')): ?> 
                                        <a href="<?php echo e(route('admin.service.get_old_payment.edit',$service_repceits['id'])); ?>"
                                            class="btn text-success fa fa-pencil hover  hover-primary" title="<?php echo app('translator')->get('site.edit'); ?>">
                                        </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete old services receipt')): ?> 
                                        <a class="btn text-danger  glyphicon glyphicon-trash hover  hover-primary"
                                            title="<?php echo app('translator')->get('site.delete'); ?>"
                                            onclick="delete_by_id('<?php echo e(route('admin.service.delete_payment_receipt')); ?>',<?php echo e($service_repceits['id']); ?>,'<?php echo e(csrf_token()); ?>','<?php echo e(json_encode(swal_fire_msg())); ?>');"
                                            >
                                        </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('print old services receipt')): ?> 
                                        <a href="<?php echo e(route('admin.payment.service.receipt',$service_repceits['id'])); ?>"
                                            class="btn text-warning fa fa-print hover  hover-primary" title="<?php echo app('translator')->get('site.print'); ?>">
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php if(isset($receipt)): ?>
                <?php echo e($receipt->links()); ?>

            <?php endif; ?>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#spinner_loading').css("display", "none");

            $('#table_std').removeAttr('hidden');
            var table = $('#example1').DataTable({
                order: [
                    [0, 'desc']
                ],
                scrollY: "400px",
                // scrollX: true,
                // scrollCollapse: true,
                responsive: true,
                paging: false,
                // ajax: '/test/0',

            });
        });
    </script>
    <script src="<?php echo e(URL::asset('assets/custome_js/delete.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/fixed_column_datatable.js')); ?>"></script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/services/receipt/index.blade.php ENDPATH**/ ?>