
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.attendance students'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"></h3>
            <div class="row">
                <div class="col-md-6">
                    <label><?php echo app('translator')->get('site.date'); ?> </label>
                    <form action="" id="attendance_form">
                        <div class="form-group">
                            <input name="attendance_date" class="form-control" type="date"  id="attendance_date"
                                onchange="get_students_by_date();" min="<?php echo e($cours->act_StartDa); ?>"
                                max="<?php echo e($cours->act_EndDa); ?>">
                                <span class="text-danger" id="attendance_date_"></span>
                        </div>
                    </form>
                    </div>
                    <div class="col-md-6">
                        <label><?php echo app('translator')->get('site.nb of hours total for cours'); ?> </label>
                        <div class="form-group">
                            <input name="total_hours" class="form-control" type="number" value=""
                                id="example-date-input">
                          
                           
                        
                        </div>
                    </div>
                </div>

            

        </div>
        <div class="box" id="spinner_loading">
            <div class="d-flex justify-content-center text-primary">
                <div class="spinner-border" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
        </div>

        

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        // $(document).ready(function() {
        //     // $('#spinner_loading').css("display", "none");

        //     // $('#attendance').removeAttr('hidden');
        //     var table = $('#attendance').DataTable({
        //         // order: [
        //         //     [0, 'desc']
        //         // ],
        //         "ordering": false,
        //         "info": false,
        //         "searching": false,
        //         paging: false,

        //     });
        // });
    </script>
    <script src="<?php echo e(URL::asset('assets/custome_js/attendance.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/students-attendance/students-for-cours.blade.php ENDPATH**/ ?>