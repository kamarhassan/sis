<div class="col-md-12 col-12">
    <div class="box-body">
        <form wire:submit.prevent="validate_client_service">
            <div class="col-md-12">
                <div class="form-gourp">
                    <label>
                        <?php echo app('translator')->get('site.students'); ?> <span class="text text-danger">*</span>
                    </label>
                    <input wire:model='client_name' wire:keypress.debounce.500ms="updateQuery()" class='form-control'
                        type="text" placeholder="<?php echo app('translator')->get('site.searche std'); ?>" list="std_list" wire:keydown.escape="reset_"
                        wire:keydown.tab="reset_" name="client_name">
                    <?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?> </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if(!empty($client_name)): ?>
                        <div wire:loading wire:target="updateQuery()"> </div>
                        <div class="fixed  top-0 bottom-0 left-0 right-0" wire:click="reset_"></div>
                        <div class="absolute z-10 w-full bg-white rounded-t-none shadow-lg list-group">
                            <?php if(!empty($all_client_name)): ?>
                                <datalist id="std_list" class="col-md-12">
                                    <?php $__currentLoopData = $all_client_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="form-control" value="<?php echo e($client['name']); ?>">
                                            <?php echo e($client['id']); ?>#<?php echo e($client['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            <?php else: ?>
                                <div wire:loading.remove>
                                    
                                    <span class="text-danger"> <?php echo app('translator')->get('site.No results!'); ?></span>
                                    
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <div class="form-group">
                        <label><?php echo app('translator')->get('site.cours'); ?> <span class="text text-danger">*</span> </label>
                        <select wire:model="service_id" wire:change="get_service()" name="service_id"
                            class="form-control " style="width: 100%;">
                            <?php if(isset($services)): ?>
                                <option value=""><?php echo app('translator')->get('site.chosse the services'); ?></option>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $services_): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($services_->id); ?>">
                                        <span class=""># <?php echo e($services_['id']); ?> # </span>
                                        <span class=""><?php echo e($services_['service']); ?> -</span>
                                        <span class=""><?php echo e($services_['fee']); ?> </span>
                                        
                                        <span class=""> <?php echo e($services_['currency']['abbr']); ?></span>
                                        
                                        
                                        
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <button class="btn  glyphicon glyphicon-arrow-left hover-success text-warning-light"
                title="<?php echo app('translator')->get('site.save'); ?>" type="submit"> <span> <?php echo app('translator')->get('site.next step'); ?></span>
            </button>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/livewire/services/servicesclient.blade.php ENDPATH**/ ?>