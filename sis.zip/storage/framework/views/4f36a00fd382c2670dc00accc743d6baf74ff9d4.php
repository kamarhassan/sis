<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\sis\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>