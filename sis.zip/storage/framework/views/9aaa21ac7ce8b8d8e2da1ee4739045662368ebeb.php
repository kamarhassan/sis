
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box bl-3 border-warning br-3">

        <div class="box-body">
            <div class="box-header with-border">
                <h3 class="box-title text-capitalize text-warning text-uppercase">
                    
                </h3>
            </div>
            <div class="row show-grid">
                <div class="col-md-6">
                    <span>
                        <?php echo app('translator')->get('site.client name'); ?> : <span class="bb-1 border-success">

                            <?php if(isset($user)): ?>
                                <?php echo e($user['name']); ?>

                            <?php endif; ?>

                        </span>
                    </span>
                </div>
                <div class="col-md-6">
                    <span>
                        <?php echo app('translator')->get('site.services info'); ?> : <span class="bb-1 border-success">
                            <?php if(isset($service)): ?>
                                <?php echo e($service['service']); ?> # <?php echo e($service['fee']); ?> <?php echo e($service['currency']['abbr']); ?>

                            <?php endif; ?>
                        </span>
                    </span>
                </div>
            </div> <!-- End of row show-grid cours info and std name -->
        </div>


        <div class="box">
            <div class="col-md-4">
                <input type="hidden">
                <h4 class=" bb-1  border-danger box-title text-capitalize  text-uppercase" style="color:rgb(255, 153, 0)">
                    <?php echo app('translator')->get('site.fee of this services is'); ?>
                    <?php if(isset($service)): ?>
                        <?php echo e($service['currency']['currency']); ?> - <?php echo e($service['currency']['abbr']); ?> -
                        <?php echo e($service['currency']['symbol']); ?>

                    <?php endif; ?>
                </h4>
            </div>
            <form id="payment_data">
                <div class="box ">
                    <div class="row show-grid">
                        <div class="col-md-3">
                            <span>
                                <?php echo app('translator')->get('site.amount'); ?> :
                            </span>
                        </div>

                        <input type="hidden" name="service_id" id="service_id"
                            value="<?php echo e(encript_custome($service['id'])); ?>">
                        <input type="hidden" name="user_id" id="user_id" value="<?php echo e(encript_custome($user['id'])); ?>">
                        <input type="hidden" name="client_services_id" id="client_services_id" value="<?php echo e(encript_custome($client_services['id'])); ?>">

                        <input type="hidden" name="service_currency_abbr" id="service_currency_abbr"
                            value="<?php echo e($service['currency']['abbr']); ?>">
                        <input type="hidden" name="service_currency_id" id="service_currency_abbr"
                            value="<?php echo e($service['currency']['id']); ?>">



                        <?php echo csrf_field(); ?>
                        <div class="col-md-6" id="normal_pament">
                            <input type="number" id="amount_to_paid" step="any" class='form-control'
                                placeholder="<?php echo app('translator')->get('site.paid fee here'); ?>" name="amount_to_paid" value="0">
                            <span class="text-danger" id="amount_to_paid_"> </span>
                        </div>

                        <div class="col-md-6" id="Other_payment" hidden>
                            <div class="col-md-6" id="normal_pament">
                                <?php echo app('translator')->get('site.paid fee here'); ?>
                                <input type="number" id="other_amount_to_paid" step="any" class='form-control'
                                    placeholder="<?php echo app('translator')->get('site.paid fee here'); ?>" name="other_amount_to_paid" value="0">
                                <span class="text-danger" id="other_amount_to_paid_"> </span>
                            </div>
                            <div class="col-md-6" id="normal_pament">
                                <?php echo app('translator')->get('site.rate exchange'); ?>
                                <input type="number" id="rate" step="any" class='form-control'
                                    placeholder="<?php echo app('translator')->get('site.rate'); ?>" name="rate" value="0">
                                <span class="text-danger" id="rate_"> </span>
                            </div>
                            <div class="col-md-6" id="normal_pament">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('site.cours currency'); ?> </label>
                                    <select name="other_payment_currency" class="form-control select2" style="width: 100%;">
                                        <?php $__currentLoopData = $service_currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_currencys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($service['currencies_id'] != $service_currencys->id): ?>
                                                <option value="<?php echo e($service_currencys->id); ?>">
                                                    <?php echo e($service_currencys->symbol); ?> <- <?php echo e($service_currencys->currency); ?>

                                                        </option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                            </div>
                            <span class="text-danger" id="cours_currency_"> </span>
                        </div>


                        <div class="col-md-2">
                            <div class="demo-checkbox">
                                <input type="checkbox" name="payment_methode" id="payment_methode" class="chk-col-success"
                                    onchange='change_payment_methode();' value="1" />
                                <label for="payment_methode"><?php echo app('translator')->get('site.other payment'); ?></label>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="box ">
                    <div class="row show-grid">
                        <div class="col-md-3">
                            <span>
                                <?php echo app('translator')->get('site.receipt description'); ?> :
                            </span>
                        </div>
                        <div class="col-md-6">
                            <input type="text" class='form-control' placeholder="<?php echo app('translator')->get('site.description'); ?>"
                                name="receipt_description" id="receipt_description">
                            <span class="bb-1 border-success">
                        </div>
                    </div>
                </div>
                <div class="box ">
                    <div class="row show-grid">
                        <div class="col-md-3">
                            <span>
                                <?php echo app('translator')->get('site.payment type'); ?> <span class="bb-1 border-success">
                                </span>
                            </span>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <div class="radio">
                                    <input name="pay_type" type="radio" id="pay_cache_" checked
                                        onclick="change_pay_type(this.value);" value="pay_cache_">
                                    <label for="pay_cache_">cache</label>
                                    <input name="pay_type" type="radio" id="pay_check_"
                                        onclick="change_pay_type(this.value);" value="pay_check_">
                                    <label for="pay_check_">check</label>
                                    <span class="text-danger" id="pay_by_check_"> </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12" id="div_pay_check" hidden>
                    <div class="col-md-6" id="normal_pament">
                        <label>#<?php echo app('translator')->get('site.check number'); ?></label>
                        <input class='form-control' id="check_number" type="number" step="any"
                            placeholder="<?php echo app('translator')->get('site.Enter check number'); ?>" name="check_number" id="check_number">
                        <span class="text-danger" id="check_number_"> </span>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label>#<?php echo app('translator')->get('site.bank'); ?></label>
                            <select class="form-control select2" name="bank" id="bank"
                                class="form-control select2" style="width: 100%;">
                                <option></option>
                                <option>slect from bank list 2</option>
                                <option>slect from bank list3 </option>
                                <option>slect from bank list 4</option>
                                <option>slect from bank list 5</option>

                            </select>
                        </div>
                    </div>
                    <span class="text-danger" id="bank_"> </span>
                </div>



            </form>
 <div class="row">
                <div class="col-md-3">
                    <button class="btn  glyphicon glyphicon-arrow-left hover-success " title="<?php echo app('translator')->get('site.save'); ?>"
                        type="submit" onclick="savepayment('<?php echo e(route('admin.payment.payment_client_to_receipt')); ?>');">

                        <span class=""> <?php echo app('translator')->get('site.next step'); ?></span>
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('assets/custome_js/payment_for_cours_and_services.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/select2/dist/js/select2.full.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/bootstrap-select/dist/js/bootstrap-select.js')); ?>">
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/services/payment/payment.blade.php ENDPATH**/ ?>