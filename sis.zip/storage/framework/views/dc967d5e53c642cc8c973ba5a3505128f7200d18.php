<?php
$prefix = Request::route()->getprefix();
$routes = Route::current()->getName();
// dd($prefix);
?>
<aside class="main-sidebar">
    <!-- sidebar-->
    <section class="sidebar">

        <div class="user-profile">
            <div class="ulogo">
                <a href="<?php echo e(route('admin.dashborad')); ?>">
                    <!-- logo for regular state and mobile devices -->
                    <div class="d-flex align-items-center justify-content-center">
                        <img src="<?php echo e(URL::asset('assets/images/logo-dark.png')); ?>" alt="">
                        <h3><b><?php echo app('translator')->get('site.site name'); ?></h3>
                    </div>
                </a>
            </div>
        </div>

        <!-- sidebar menu-->
        <ul class="sidebar-menu" data-widget="tree">

            <li>
                <a href="<?php echo e(route('admin.dashborad')); ?>">
                    <i data-feather="pie-chart"></i>
                    <span><?php echo app('translator')->get('site.Dashboard'); ?></span>
                </a>
            </li>


            

            <?php echo $__env->make('admin.layouts.nav_bar_layouts.setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            


            
            <?php echo $__env->make('admin.layouts.nav_bar_layouts.cours', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            

            

            <?php echo $__env->make('admin.layouts.nav_bar_layouts.students', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            


            
            <?php echo $__env->make('admin.layouts.nav_bar_layouts.service', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            

            
          
            <?php echo $__env->make('admin.layouts.nav_bar_layouts.reports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           
            
        




            


            

            
            
        </ul>

    </section>

    <div class="sidebar-footer">
        <!-- item-->
        <a href="javascript:void(0)" class="link" data-toggle="tooltip" title="" data-original-title="Settings"
            aria-describedby="tooltip92529"><i class="ti-settings"></i></a>
        <!-- item-->
        <a href="mailbox_inbox.html" class="link" data-toggle="tooltip" title="" data-original-title="Email"><i
                class="ti-email"></i></a>
        <!-- item-->
        <a href="javascript:void(0)" class="link" data-toggle="tooltip" title="" data-original-title="Logout"><i
                class="ti-lock"></i></a>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/layouts/navbar_container.blade.php ENDPATH**/ ?>