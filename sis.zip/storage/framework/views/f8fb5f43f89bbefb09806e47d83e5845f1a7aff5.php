
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .modal {
            display: block !important;
            /* I added this to see the modal, you don't need this */
        }

        /* Important part */
        .modal-dialog {
            overflow-y: initial !important
        }

        .modal-body {
            height: 80vh;
            overflow-y: auto;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create roles')): ?>
        <div class="row float-right">
            <a type="button" class="btn btn-rounded btn-info" data-toggle="modal" data-target="#modal-center">
                
                <?php echo app('translator')->get('permission.add new role'); ?>
            </a>
        </div>
    <?php endif; ?>


    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit roles', 'delete roles'])): ?>
        <?php if(isset($roles)): ?>
            <div class="box-body">
                <div class="table-responsive ">
                    <table id="example1" style="width: 100%" class="table table-hover display nowrap ">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo app('translator')->get('site.role name'); ?></th>

                                
                                <th><?php echo app('translator')->get('site.options'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="Row<?php echo e($item['id']); ?>" id="Row<?php echo e($item['id']); ?>">
                                    <td>
                                        <span class="text-warning"> <?php echo e($item['id']); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-warning"> <?php echo e($item['name']); ?></span>
                                    </td>
                                    
                                    <td>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit roles')): ?>
                                            <?php if($item['name'] != 'super admin'): ?>
                                                <a onclick="get_permission('<?php echo e(route('admin.setting.get.permission.for.role', $item['id'])); ?>','<?php echo e(csrf_token()); ?>');"
                                                    class="btn text-success fa fa-pencil hover  hover-primary"
                                                    title="<?php echo app('translator')->get('site.edit'); ?>">
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete roles')): ?>
                                            <?php if($item['name'] != 'super admin' && $item['name'] != 'teacher'): ?>
                                                <a class="btn text-danger  glyphicon glyphicon-trash hover  hover-primary"
                                                    title="<?php echo app('translator')->get('site.delete'); ?>"
                                                    onclick="delete_by_id('<?php echo e(route('admin.setting.delete.role')); ?>',<?php echo e($item['id']); ?>,'<?php echo e(csrf_token()); ?>','<?php echo e(json_encode(swal_fire_msg())); ?>');">
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    <?php echo $__env->make('admin.role-and-permission.edit-permission-for-role', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {

            var table = $('#example1').DataTable({
                // order: [
                //     [0, 'desc']
                // ],
                searching: false,
                info: false,
                scrollY: "400px",
                responsive: true,
                // scrollX: true,
                // scrollCollapse: true,
                paging: false,
                // ajax: '/test/0',

            });
        });
    </script>
    <script src="<?php echo e(URL::asset('assets/custome_js/save_and_redirect.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/custome_js/role_and_permission.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/custome_js/delete.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/advanced-form-element.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/role-and-permission/create.blade.php ENDPATH**/ ?>