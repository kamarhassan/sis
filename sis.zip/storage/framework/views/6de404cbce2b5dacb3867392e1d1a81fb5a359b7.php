
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.register Student in Course'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>


    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('students.registration')->html();
} elseif ($_instance->childHasBeenRendered('bSbiUNs')) {
    $componentId = $_instance->getRenderedChildComponentId('bSbiUNs');
    $componentTag = $_instance->getRenderedChildComponentTagName('bSbiUNs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bSbiUNs');
} else {
    $response = \Livewire\Livewire::mount('students.registration');
    $html = $response->html();
    $_instance->logRenderedChild('bSbiUNs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script>

        // $(document).ready(function() {
        //     var table = $('#payment_table').DataTable({
        //         scrollY: "300px",
        //         scrollX: true,
        //         scrollCollapse: true,
        //         paging: false,
        //         fixedColumns: {
        //             left: 1,
        //             right: 1
        //         }
        //     });
        // });






        window.addEventListener('alert', event => {
            toastr[event.detail.type](event.detail.message,
                event.detail.title ?? ''), toastr.options = {
                "closeButton": true,
                "progressBar": true,
            }
        });
    </script>


    <script src="<?php echo e(URL::asset('assets/custome_js/print.js')); ?>"></script>
    
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/jquery-steps-master/build/jquery.steps.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/advanced-form-element.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_plugins/JqueryPrintArea/demo/jquery.PrintArea.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/invoice.js')); ?>"></script>
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/livewire/students/std_registration.blade.php ENDPATH**/ ?>