
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.services'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



    <div class="col-md-12 col-12">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create setting services')): ?>
            <div class="box box-slided-up">
                <div class="box-header with-border">
                    <div class="box-header with-border">
                        <h4 class="box-title"><?php echo app('translator')->get('site.add services'); ?></h4>
                    </div>
                    <ul class="box-controls pull-right">
                        <li><a class="box-btn-close" href="#"></a></li>
                        <li><a class="box-btn-slide text-warning" href="#"></a></li>
                        
                    </ul>
                </div>


                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <div class="col-12">
                            <form id='services_form'>
                                <?php echo csrf_field(); ?>
                                <div class="add_item">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <h5><?php echo app('translator')->get('site.services'); ?> <span class="text-danger">*</span></h5>
                                                <div class="controls">
                                                    <input type="text" id="services_0" name="services[]"
                                                        class="form-control">
                                                    <span class="text-danger" id="services_0_"> </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <h5><?php echo app('translator')->get('site.fee value'); ?> <span class="text-danger">*</span></h5>
                                                <div class="controls">
                                                    <input type="text" id="fee_0" name="fee[]" class="form-control">
                                                    <span class="text-danger" id="fee_0_"> </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <h5><?php echo app('translator')->get('site.currency name'); ?> <span class="text-danger">*</span></h5>
                                                <div class="controls">
                                                    <?php if(isset($currency)): ?>
                                                        <select name="currency[]" id="currency_0" class="form-control select2"
                                                            style="width: 100%;">
                                                            <option value="">--------------</option>
                                                            <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currencys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($currencys->id); ?>">
                                                                    <?php echo e($currencys->symbol); ?> <- <?php echo e($currencys->currency); ?> </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    <?php endif; ?>
                                                    <span class="text-danger" id="currency_0_"> </span>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-2" style="padding-top: 25px;">
                                            <span class="btn btn-success addeventmore"><i class="fa fa-plus-circle"></i>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                            </form>
                            <div class="row">
                                <div class="text-xs-right">
                                    <a class="btn  glyphicon glyphicon-arrow-left hover-success " title="<?php echo app('translator')->get('site.save'); ?>"
                                        onclick="services('<?php echo e(route('admin.Services.store')); ?>','services_form')">
                                        <span class=""> <?php echo app('translator')->get('site.next step'); ?></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit setting services', 'delete setting services'])): ?>

            <?php echo $__env->make('admin.services.services.services-data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('admin.services.services.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php endif; ?>


        <div style="visibility: hidden;">
            <div class="whole_extra_item_add" id="whole_extra_item_add">
                <div class="delete_whole_extra_item_add" id="delete_whole_extra_item_add">
                    <div class="form-row">
                        <div class="col-md-3">

                            <div class="form-group">
                                <h5><?php echo app('translator')->get('site.services'); ?> <span class="text-danger">*</span></h5>
                                <div class="controls">
                                    <input type="text" id="services_number" name="services[]" class="form-control">
                                    <span class="text-danger" id="services_number_error"> </span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <h5><?php echo app('translator')->get('site.fee value'); ?> <span class="text-danger">*</span></h5>
                                <div class="controls">
                                    <input type="text" id="fee_number" name="fee[]" class="form-control">
                                    <span class="text-danger" id="fee_number_error"> </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <h5><?php echo app('translator')->get('site.currency name'); ?> <span class="text-danger">*</span></h5>
                                <div class="controls">
                                    <?php if(isset($currency)): ?>
                                        <select name="currency[]" id="currency_number" class="form-control "
                                            style="width: 100%;">
                                            <option value="">--------------</option>
                                            <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currencys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($currencys->id); ?>">
                                                    <?php echo e($currencys->symbol); ?> <- <?php echo e($currencys->currency); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    <?php endif; ?>
                                    <span class="text-danger" id="currency_number_error"> </span>
                                </div>
                            </div>
                        </div>


                        <div class="col-md-2" style="padding-top: 25px;">
                            <span class="btn btn-success addeventmore"><i class="fa fa-plus-circle"></i> </span>
                            <span class="btn btn-danger removeeventmore"><i class="fa fa-minus-circle"></i> </span>
                        </div><!-- End col-md-2 -->
                    </div><!-- End col-md-5 -->
                </div>
            </div>
        </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>
        <script type="text/javascript">
            $(document).ready(function() {
                var counter = 1;
                $(document).on("click", ".addeventmore", function() {
                    var whole_extra_item_add = $('#whole_extra_item_add').html();
                    $(this).closest(".add_item").append(whole_extra_item_add);
                    $("#services_number").attr("id", "services_" + counter);
                    $("#services_number_error").attr("id", "services_" + counter + "_");

                    $("#fee_number").attr("id", "fee_" + counter);
                    $("#fee_number_error").attr("id", "fee_" + counter + "_");

                    $("#currency_number").attr("id", "currency_" + counter);
                    $("#currency_number_error").attr("id", "currency_" + counter + "_");

                    $("#status_number").attr("id", "status_" + counter);
                    $("#status_number_error").attr("id", "status_" + counter + "_");
                    // $(this).closest(".add_item").attr("id","whole_extra_item_add_"+counter);;

                    counter++;
                });
                $(document).on("click", '.removeeventmore', function(event) {
                    $(this).closest(".delete_whole_extra_item_add").remove();
                    counter -= 1
                });



                $('#spinner_loading').css("display", "none");

                $('#services-table-').removeAttr('hidden');

                var table = $('#services-table').DataTable({
                    scrollY: "400px",
                    // scrollX: true,
                    scrollCollapse: true,
                    paging: false,
                    responsive: true,
                    // ajax: '/test/0',

                });
            });
        </script>

        <script src="<?php echo e(URL::asset('assets/custome_js/services.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/custome_js/delete.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/custome_js/update.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/advanced-form-element.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/assets/vendor_components/select2/dist/js/select2.full.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/assets/vendor_components/bootstrap-select/dist/js/bootstrap-select.js')); ?>">
        </script>
        <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/toastr.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/services/services/create.blade.php ENDPATH**/ ?>