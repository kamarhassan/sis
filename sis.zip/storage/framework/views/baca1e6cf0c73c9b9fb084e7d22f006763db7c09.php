<div>
    
    
    <?php if($current_step == 1): ?>


        <div class="text-center text-capitalize ">
            <h1 class="text-warning"><label><?php echo app('translator')->get('site.registration std step 1'); ?> </label></h1>
        </div>

        <form wire:submit.prevent="validate_std_register">
            <div class="col-md-12">
                <div class="form-gourp">
                    <label>
                        <?php echo app('translator')->get('site.students'); ?> <span class="text text-danger">*</span>
                    </label>
                    <input wire:model='std_name' wire:keypress.debounce.500ms="updateQuery()"
                        class='form-control' type="text" placeholder="<?php echo app('translator')->get('site.searche std'); ?>" list="std_list"
                        wire:keydown.escape="reset_" wire:keydown.tab="reset_" name="std_name">
                    

                    <?php $__errorArgs = ['std_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?> </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <?php if(!empty($std_name)): ?>
                    <div wire:loading wire:target="updateQuery()"> </div>

                        <div class="fixed  top-0 bottom-0 left-0 right-0" wire:click="reset_">

                        </div>
                        <div class="absolute z-10 w-full bg-white rounded-t-none shadow-lg list-group">
                            <?php if(!empty($all_std_as_std_name)): ?>
                                <datalist id="std_list" class="col-md-12">
                                    <?php $__currentLoopData = $all_std_as_std_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="form-control" value="<?php echo e($student['name']); ?>">
                                            <?php echo e($student['id']); ?>#<?php echo e($student['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </datalist>
                            <?php else: ?>
                                <div wire:loading.remove>
                                    
                                    <span class="text-danger"> <?php echo app('translator')->get('site.No results!'); ?></span>
                                    
                                </div>
                            <?php endif; ?>
                        </div>

                    <?php endif; ?>

                </div>

            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <div class="form-group">
                        <label><?php echo app('translator')->get('site.cours'); ?> <span class="text text-danger">*</span> </label>
                        <select wire:model="cours_id" wire:change="get_cours_fee($event.target.value)" name="cours_id"
                            class="form-control " style="width: 100%;">
                            <?php if(isset($cours)): ?>
                                <option value=""><?php echo app('translator')->get('site.chosse the cours'); ?></option>
                                <?php $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cours_): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cours_->id); ?>"><?php echo e($cours_->id); ?> -
                                        <?php echo e($cours_->grade['grade']); ?> -
                                        <?php echo e($cours_->level['level']); ?> - <?php echo e($cours_->teacher['name']); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php $__errorArgs = ['cours_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <?php if($cours_fee_count > 0): ?>
                <div class="table-responsive">
                    <div class="box-header with-border">
                        <h4 class="box-title"><?php echo app('translator')->get('site.fee of this cours is'); ?>
                            <span class="badge badge-pill badge-danger">
                                <?php echo e($cours_fee[0]->currency['currency']); ?> -> <?php echo e($cours_fee[0]->currency['abbr']); ?>

                            </span>
                        </h4>
                    </div>
                    <table class="table table-hover mb-0">
                        <tr>
                            <th scope="col"><?php echo app('translator')->get('site.fee type'); ?></th>
                            <th scope="col"><?php echo app('translator')->get('site.fee value'); ?></th>
                        </tr>

                        <?php $__currentLoopData = $cours_fee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cours_fe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($cours_fe->fee_type['fee']); ?></td>
                                <td scope="row"><?php echo e($cours_fe->value); ?></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr scope="col" class="text-warning text-uppercase">
                            <td scope="row"><?php echo app('translator')->get('site.cours fee total'); ?> </td>
                            <td scope="row"> <?php echo e($cours_fee_sum); ?></td>
                        </tr>
                    </table>
                </div>
            <?php elseif($cours_fee_count == 0): ?>
                <div>
                    <label>
                        <span class="border-warning">
                            <h3 class="text-danger">
                                <?php echo app('translator')->get('site.fee of this cours note defined'); ?>
                            </h3>
                        </span>
                    </label>
                </div>
            <?php else: ?>
            <?php endif; ?>
            <div>

                <?php if($cours_fee_count == 0): ?>
                    <a class="btn glyphicon glyphicon-arrow-left hover-danger text-danger text-light" disabled
                        title="<?php echo app('translator')->get('site.save'); ?>">
                    </a><span class="text text-danger"> <?php echo app('translator')->get('site.next step'); ?></span>
                <?php elseif($cours_fee_count < 0): ?>
                    <a class="btn glyphicon glyphicon-arrow-left hover-danger text-danger text-light" disabled
                        title="<?php echo app('translator')->get('site.save'); ?>">
                    </a><span class="text text-danger"> <?php echo app('translator')->get('site.next step'); ?></span>
                <?php else: ?>
                    <button class="btn  glyphicon glyphicon-arrow-left hover-success text-warning-light"
                        title="<?php echo app('translator')->get('site.save'); ?>" type="submit"> <span> <?php echo app('translator')->get('site.next step'); ?></span>
                    </button>
                <?php endif; ?>

            </div>

        </form>
    <?php elseif($current_step == 2): ?>
        <?php echo $__env->make('admin.livewire.students.fee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($current_step == 3): ?>
        <?php echo $__env->make('admin.livewire.students.payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($current_step == 4): ?>
        <?php echo $__env->make('admin.livewire.students.report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/livewire/students/registration.blade.php ENDPATH**/ ?>