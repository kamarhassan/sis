
<div class="modal bs-examplemodal-lg  center-modal  " id="modal-center" tabindex="-1" tabindex="-1" role="dialog"
    aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                
                <a type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <div class="modal-body">

                
                <div class="box-body">
                    <div class="row">
                        <div class="col-12">
                            <form id='services_form_edit'>
                                <?php echo csrf_field(); ?>
                                <input hidden name="service_id" id="service_id">
                                <div class="add_item">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <h5><?php echo app('translator')->get('site.services'); ?> <span class="text-danger">*</span></h5>
                                                <div class="controls">
                                                    <input type="text" id="service" name="service"
                                                        class="form-control">
                                                    <span class="text-danger" id="service_"> </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <h5><?php echo app('translator')->get('site.fee value'); ?> <span class="text-danger">*</span></h5>
                                                <div class="controls">
                                                    <input type="text" id="fee" name="fee"
                                                        class="form-control">
                                                    <span class="text-danger" id="fee_"> </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <h5><?php echo app('translator')->get('site.currency name'); ?> <span class="text-danger">*</span></h5>
                                                <div class="controls">
                                                    <?php if(isset($currency)): ?>
                                                        <select name="currency" id="currency" class="form-control select2"
                                                            style="width: 100%;">

                                                            <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currencys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($currencys->id); ?>">
                                                                    <?php echo e($currencys->symbol); ?> <- <?php echo e($currencys->currency); ?>

                                                                        </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    <?php endif; ?>
                                                    <span class="text-danger" id="currency_"> </span>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <h5><?php echo app('translator')->get('site.is active'); ?> <span class="text-danger"></span></h5>
                                            <div class="form-group">
                                                <div class="box-controls pull-left">
                                                    <label class="switch switch-border switch-success">
                                                        <input type="checkbox" value="1" name="active"
                                                            id="active" />
                                                        <span class="switch-indicator"></span>
                                                        <label for="switcheryColor4"
                                                            class="card-title ml-1"><?php echo app('translator')->get('site.is active'); ?> </label>

                                                        <span class="text-danger" id="active_"> </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        </form>
                        <div class="row">
                            <div class="text-xs-right">
                                <a class="btn  glyphicon glyphicon-arrow-left hover-success " title="<?php echo app('translator')->get('site.save'); ?>"
                                    onclick="services('<?php echo e(route('admin.services.update')); ?>','services_form_edit')">
                                    <span class=""> <?php echo app('translator')->get('site.next step'); ?></span>
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        
    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/services/services/edit.blade.php ENDPATH**/ ?>