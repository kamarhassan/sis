
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('see notification')): ?> 
    
    <li class="dropdown user notifications-menu">
        <a href="#" class="waves-effect waves-light rounded dropdown-toggle" data-toggle="dropdown" title="Notifications">
            <i class="ti-bell">
                
                <?php if(get_count_notification() > 0): ?>
                    <div class="pulse  marker pulseWarningIns">
                        <?php echo e(get_count_notification()); ?>

                    </div>
                <?php endif; ?>
            </i>
        </a>
        <?php if(get_count_notification() > 0): ?>
            <ul class="dropdown-menu animated bounceIn">
                <li class="header">
                    <div class="p-20">
                        <div class="flexbox">
                            <div>
                                <h4 class="mb-0 mt-0">Notifications</h4>
                            </div>
                            
                        </div>
                    </div>
                </li>
                <li>
                    <ul class="menu sm-scrol">
                        <?php $__currentLoopData = get_type_notification(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notifcation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="#">
                                    <i class="fa fa-users text-info"></i> <?php echo app('translator')->get('site.' . $notifcation['description']); ?>
    
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="footer">
                    <a href="<?php echo e(route('admin.new.register.order')); ?>">View all</a>
                </li>
            </ul>
        <?php else: ?>
            <ul class="dropdown-menu animated bounceIn">
                <li class="header">
                    <ul class="menu sm-scrol">
                        <li>
                            <a href="#">
                                <i class="fa fa-users text-info"></i>
                                <?php echo app('translator')->get('site.you dont have any notification'); ?>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        <?php endif; ?>
    </li>
    
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/layouts/admin-notification-bar.blade.php ENDPATH**/ ?>