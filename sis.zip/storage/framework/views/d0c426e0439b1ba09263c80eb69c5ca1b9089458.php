
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.reports'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div>



        <div class="col-md-12 col-12">
            <div class="box">
                <div class="box-header with-border">
                    <form id="report">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('site.start date'); ?> </label>
                                    <input name="start_date" class="form-control" type="date" id="example-date-input">
                                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('site.end date'); ?> </label>
                                    <input name="end_date" class="form-control" type="date" id="example-date-input">

                                    <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>


                    </form>
                    <ul class="box-controls pull-right">
                        
                        <li><a class="box-btn-slide text-white" href="#"></a></li>
                        
                    </ul>
                </div>

                <div class="box-body col-md-12">
                    <div class="row">
                        <div class="col-md-4">
                            <a class="btn  glyphicon glyphicon-print hover-report text-report" title=""
                                type="submit" onclick="get_report('<?php echo e(route('admin.daily.report')); ?>');"> <span>
                                    <?php echo app('translator')->get('site.daily reports'); ?></span>
                            </a>

                        </div>

                        <div class="col-md-4">
                            <a class="btn  glyphicon glyphicon-print hover-report text-report" title=""
                                type="submit" onclick="get_report('<?php echo e(route('admin.service.by.type.report')); ?>');">
                                <span> <?php echo app('translator')->get('site.Receipt Report Service Sold By Type'); ?></span>
                            </a>
                        </div>

                        <div class="col-md-4">
                            <a class="btn  glyphicon glyphicon-print hover-report text-report" title=""
                                type="submit" onclick="get_report('<?php echo e(route('admin.unpaid.account.summary.report')); ?>');">
                                <span>
                                    <?php echo app('translator')->get('site.Receipt Report unpaid accounting summary'); ?></span>
                            </a>
                        </div>

                        <div class="col-md-4">
                            <a class="btn  glyphicon glyphicon-print hover-report text-report" title=""
                                type="submit" onclick="get_report('<?php echo e(route('admin.unpaid.account.details.report')); ?>');">
                                <span>
                                    <?php echo app('translator')->get('site.Receipt Report unpaid account details'); ?></span>
                            </a>

                        </div>

                         <div class="col-md-4">
                            <a class="btn  glyphicon glyphicon-print hover-report text-report" title=""
                                type="submit" onclick="get_report('<?php echo e(route('admin.cours.account.summary.report')); ?>');"> <span>
                                    <?php echo app('translator')->get('site.Receipt Report course accounting summary'); ?></span>
                            </a>

                        </div>

                       <div class="col-md-4">
                            <a class="btn  glyphicon glyphicon-print hover-report text-report" title=""
                                type="submit"  onclick="get_report('<?php echo e(route('admin.cours.account.details.report')); ?>');"> <span>
                                    <?php echo app('translator')->get('site.Receipt Report cours accounting details'); ?></span>
                            </a>
                        </div>

                    </div>
                </div>

            </div>
        </div>
        <div class="row-fluid" id='data-report' hidden>
            <?php echo $__env->make('admin.reports.report-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('assets/custome_js/reports.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/data-table-responsive/datatable-responsive.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>