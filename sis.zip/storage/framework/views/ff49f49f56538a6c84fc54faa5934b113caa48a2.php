
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="blog" class="blog">
        <div class="container">
            <div class="row">
                <div class="entries">
                    <article class="entry" data-aos="fade-up">
                        <div class="entry-img">
                            <img src="assets/img/blog-1.jpg" alt="" class="img-fluid">
                        </div>
                        <h2 class="entry-title">
                            <a>
                                <?php if(isset($cours)): ?>
                                    <?php echo e($cours['grade']['grade']); ?> -- <?php echo e($cours['level']['level']); ?>

                                <?php endif; ?>
                            </a>
                        </h2>
                        <div class="entry-meta">
                            <ul>
                                <li class="d-flex align-items-center"><i class="icofont-user"></i><a>
                                        <?php if(isset($teacher_name)): ?>
                                        <?php echo app('translator')->get('site.teacher name'); ?> :     <?php echo e($teacher_name['name']); ?>

                                        <?php endif; ?>
                                    </a></li>

                                <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a><time
                                            datetime="2020-01-01"><?php echo app('translator')->get('site.start date'); ?> : <?php if(isset($cours['act_StartDa'])): ?>
                                                <?php echo e($cours['act_StartDa']); ?>

                                            <?php endif; ?>
                                        </time></a></li>
                                <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a><time
                                            datetime="2020-01-01"><?php echo app('translator')->get('site.end date'); ?> : <?php if(isset($cours['act_EndDa'])): ?>
                                                <?php echo e($cours['act_EndDa']); ?>

                                            <?php endif; ?>
                                        </time></a></li>


                            </ul>
                        </div>
                        <div class="entry-content">
                            <p>
                                
                            </p>
                            <p>

                                <li class="d-flex align-items-center"><i class="icofont-book"></i> <a>
                                        <?php echo app('translator')->get('site.description cours'); ?>
                                    </a></li>
                                <?php if(isset($cours['description'])): ?>
                                    <?php echo e($cours['description']); ?>

                                <?php endif; ?>
                            </p>

                            <?php if(isset($fee)): ?>
                                <div class="box">
                                    <div class="box-header with-border">
                                        <h4 class="box-title"><?php echo app('translator')->get('site.fee amount'); ?></h4>
                                        
                                    </div>
                                    <!-- /.box-header -->
                                    <div class="box-body no-padding">
                                        <div class="table-responsive">
                                            <table class="table table-hover">
                                                <tbody>
                                                    <tr>
                                                        <th>#</th>
                                                        <th><?php echo app('translator')->get('site.fee type'); ?></th>
                                                        <th><?php echo app('translator')->get('site.fee amount'); ?></th>
                                                        
                                                    </tr>

                                                    <?php $__currentLoopData = $fee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $fee_cours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($key); ?></td>
                                                            <td><?php echo e($fee_cours['fee_type']['fee']); ?></td>
                                                            <td><?php echo e($fee_cours['value']); ?> # <?php echo e($fee_cours['currency']['symbol']); ?> - <?php echo e($fee_cours['currency']['abbr']); ?></td> 


                                                        </tr>
                                                        
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!-- /.box-body -->
                                </div>
                            <?php endif; ?>


                            <div class="">

                                <?php if(auth()->guard()->guest()): ?>
                                    <div class="read-more">
                                        <a> <?php echo app('translator')->get('site.you must be login to register in this cours'); ?></a>
                                    </div>
                                    
                                <?php else: ?>
                                    <?php if(auth()->guard()->check()): ?>

                                        <form id="reserve_cours">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="user_id" id="" value="<?php echo e(Auth::user()->id); ?>">
                                            <input type="hidden" name="order_id" id="" value="<?php echo e($cours['id']); ?>">
                                            <input type="hidden" name="order_type" id="" value="<?php echo e(Crypt::encryptString ('registration')); ?>">
                                            
                                            <div class="read-more">
                                                <a onclick="submit('<?php echo e(route('web.registerCours')); ?>','reserve_cours')"><?php echo app('translator')->get('site.reserve cours'); ?></a>
                                            </div>
                                        </form>
                                    <?php endif; ?>

                                <?php endif; ?>



                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(URL::asset('assets/custome_js/save.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/frontend/cours/cours-detail.blade.php ENDPATH**/ ?>