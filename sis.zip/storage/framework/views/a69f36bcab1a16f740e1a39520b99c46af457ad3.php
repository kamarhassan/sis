<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
    'edit language',
    'edit grades',
    'create grades',
    'delete grades',
    'levels',
    'edit levels',
    'create levels',
    'delete levels',
    'activate_currency',
    'setting services',
    'create setting services',
    'edit setting services',
    'delete
    setting services',
    'roles',
    'create roles',
    'edit roles',
    'delete roles',
    'fee type',
    'edit fee type',
    'create fee type',
    'delete fee type',
    'edit supervisor',
    'delete supervisor',
    'add supervisor',
    ])): ?>


    <li class="treeview   <?php echo e($prefix == getprefix('setting') ? 'active' : ''); ?>     ">
        <a href="#">
            <i class="ti-settings"></i>
            <span><?php echo app('translator')->get('site.setting'); ?></span>
            <span class="pull-right-container">
                <i class="fa fa-angle-right pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit supervisor', 'delete supervisor', 'add supervisor'])): ?>
                <li class="treeview   <?php echo e($prefix == getprefix('supervisor') ? 'active' : ''); ?>     ">
                    <a href="#">
                        <i class="si si-people"></i>
                        <span><?php echo app('translator')->get('site.supervisor'); ?></span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-right pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit supervisor', 'delete supervisor'])): ?>
                            <li><a href="<?php echo e(route('admin.supervisor.all')); ?>">
                                    <i class="ti-more">
                                    </i>
                                    <?php echo app('translator')->get('site.all supervisor'); ?>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add supervisor')): ?>
                            <li><a href="<?php echo e(route('admin.supervisor.add')); ?>">
                                    <i class="ti-more">
                                    </i>
                                    <?php echo app('translator')->get('site.supervisor add'); ?>
                                </a>
                            </li>
                        <?php endif; ?>

                    </ul>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit language')): ?>
                <li><a href="<?php echo e(route('admin.language')); ?>">
                        <i class="ti-more">
                        </i>
                        <?php echo app('translator')->get('site.website language'); ?>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit grades', 'create grades', 'delete grades'])): ?>
                <li><a href="<?php echo e(route('admin.grades.add')); ?>">
                        <i class="ti-more"></i><?php echo app('translator')->get('site.add new grade'); ?></a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit levels', 'create levels', 'delete levels'])): ?>
                <li><a href="<?php echo e(route('admin.level.add')); ?>">
                        <i class="ti-more"></i><?php echo app('translator')->get('site.add new level'); ?></a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activate_currency')): ?>
                <li><a href="<?php echo e(route('admin.Currency.get')); ?>">
                        <i class="ti-more"></i><?php echo app('translator')->get('site.add new Currency'); ?></a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([ 'create setting services', 'edit setting services', 'delete setting services'])): ?>
                <li><a href="<?php echo e(route('admin.Services.add')); ?>">
                        <i class="ti-more"></i>
                        <?php echo app('translator')->get('site.add and edit services'); ?>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create roles', 'edit roles', 'delete roles'])): ?>
                <li><a href="<?php echo e(route('admin.setting.role')); ?>">
                        <i class="ti-more"></i>
                        <?php echo app('translator')->get('site.role and permission'); ?>
                    </a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['fee type', 'edit fee type', 'create fee type', 'delete fee type'])): ?>
                <li><a href="<?php echo e(route('admin.setting.fee')); ?>">
                        <i class="ti-more"></i>
                        <?php echo app('translator')->get('site.fees'); ?>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/layouts/nav_bar_layouts/setting.blade.php ENDPATH**/ ?>