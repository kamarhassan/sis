<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['register service to client', 'old services receipt', 'edit old services receipt', 'delete old services
    receipt', 'print old services receipt'])): ?>
    <li class="treeview   <?php echo e($prefix == getprefix('services') ? 'active' : ''); ?>     ">
        <a href="#">
            <i class="fa fa-user-circle"></i>
            <span><?php echo app('translator')->get('site.services'); ?></span>
            <span class="pull-right-container">
                <i class="fa fa-angle-right pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('register service to client')): ?>
                <li><a href="<?php echo e(route('admin.Services.to.client')); ?>">
                        <i class="ti-more"></i>
                        <?php echo app('translator')->get('site.services'); ?>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit old services receipt', 'delete old services receipt', 'print old services receipt'])): ?>
                <li><a href="<?php echo e(route('admin.Services.all-receipt')); ?>" >
                        <i class="ti-more">
                        </i>
                        <?php echo app('translator')->get('site.edit receipt and payment'); ?>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/layouts/nav_bar_layouts/service.blade.php ENDPATH**/ ?>