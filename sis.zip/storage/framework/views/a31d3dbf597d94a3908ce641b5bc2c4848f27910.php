

<?php $__env->startSection('css'); ?>
    <style>
        cursor_pointer {
            cursor: pointer;
            margin: 15px 0;

        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"></h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">


            <?php if(isset($std)): ?>
                <?php $__currentLoopData = $std; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $stduents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="Row<?php echo e($stduents->id); ?>" onclick="" class="row bg-light mb-10 p-10 cursor_pointer hover-success">
                        <div class="col-sm-1"><?php echo e($stduents->id); ?></div>
                        <div class="col-sm-2"><?php echo e($stduents->name); ?> </div>
                        <div class="col-md-3"><?php echo e($stduents->email); ?></div>
                        <div class="col-md-3">
                            <img class="avatar avatar-xl avatar-1" src="<?php echo e(photos_dir($stduents->photo)); ?>" alt="">
                        </div>
                        <div class="col-md-3"><?php echo e($stduents->birthday); ?> </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>



            <?php echo e($std->links()); ?>

        </div>
    </div>
    <!-- /.box-body -->






<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/students/index.blade.php ENDPATH**/ ?>