
<div class="modal bs-examplemodal-lg  center-modal  " id="modal-center" tabindex="-1" tabindex="-1" role="dialog"
    aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <form action="" id="permission_for_role">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <span class="modal-title" id="myLargeModalLabel"> <?php echo app('translator')->get('permission.role name'); ?> : </span> <input type="text"
                        class='form-control' name="role_name" id="role_name">
                    <?php $__errorArgs = ['role_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <a onclick="reset_input();" type="button" class="close text-warning" data-dismiss="modal"
                        aria-hidden="true">×</a>
                </div>


                <div class="modal-body">
                    <div class="box">
                        <div class="box-body no-bg">
                            <ul class="nav nav-pills mb-20 no-border">
                                <?php
                                    $tab_counter_active = 0;
                                    $item_counter_active = 0;
                                ?>
                                <?php if(isset($tab_name)): ?>
                                    <?php $__currentLoopData = $tab_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="nav-item">
                                            <a href="#<?php echo e($tab['tab_name']); ?>"
                                                class="nav-link 
                                            <?php if($tab_counter_active == 0): ?> active <?php
                                            $tab_counter_active++;
                                        ?> <?php endif; ?>"
                                                data-toggle="tab" aria-expanded="false">
                                                <?php echo e($tab['tab_name']); ?></a>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                            <div class="tab-content">
                                <?php if(isset($permission)): ?>
                                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab_names => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div id="<?php echo e($tab_names); ?>"
                                            class="tab-pane  
                                    <?php if($item_counter_active == 0): ?> active <?php
                                    $item_counter_active++;
                                   ?> <?php endif; ?>">
                                            
                                            <table class="table table-striped">
                                                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission_in_tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($key); ?></td>
                                                        <td>
                                                            <div class="row">
                                                                <?php $__currentLoopData = $permission_in_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="demo-checkbox">
                                                                        <input type="checkbox" name="permission[]"
                                                                            id="md_checkbox_<?php echo e($permission['id']); ?>"
                                                                            class="chk-col-primary"
                                                                            value="<?php echo e($permission['name']); ?>" />
                                                                        <label for="md_checkbox_<?php echo e($permission['id']); ?>">
                                                                            <?php echo e($permission['name']); ?>

                                                                            
                                                                        </label>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </table>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                                <div class="text-xs-right" id="update_role" hidden>
                                    <a class="btn  glyphicon glyphicon-ok hover-success " title="<?php echo app('translator')->get('site.edit'); ?>"
                                        onclick="update_permission_for_role('<?php echo e(route('admin.setting.update.permission.for.role')); ?>','permission_for_role');"><span
                                            class=""> <?php echo app('translator')->get('site.next step'); ?></span>
                                    </a>
                                </div>
                                <div class="text-xs-right" id="new_role">
                                    <a class="btn  glyphicon glyphicon-ok hover-success " title="<?php echo app('translator')->get('site.save'); ?>"
                                        onclick="submit('<?php echo e(route('admin.setting.new.role')); ?>','permission_for_role');";><span
                                            class=""> <?php echo app('translator')->get('site.next step'); ?></span>
                                    </a>
                                </div>
                            </div>
            </form>
        </div>
    </div>

</div>
</div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/role-and-permission/edit-permission-for-role.blade.php ENDPATH**/ ?>