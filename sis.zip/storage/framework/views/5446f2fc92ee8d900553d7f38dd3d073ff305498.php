
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        active:hover {
            background-color: <?php echo app('translator')->get('site.activate'); ?>;
        }

        active:hover {
            background-color: <?php echo app('translator')->get('site.disactivate'); ?>;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">Form inputs</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <div class="table-responsive">
                <table id="example1" class="table  table-striped">
                    <thead>
                        <tr>

                            <th><?php echo app('translator')->get('site.currency name'); ?></th>
                            <th><?php echo app('translator')->get('site.currency abbr'); ?></th>
                            <th><?php echo app('translator')->get('site.currency country'); ?></th>
                            <th><?php echo app('translator')->get('site.currency symbol'); ?></th>
                            
                            <th><?php echo app('translator')->get('site.options'); ?></th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php if(isset($currency)): ?>
                            <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currenc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                   
                                    <td>
                                        <?php if($currenc->active == 1): ?>
                                            <div class="box-body ribbon-box">
                                                <div class="ribbon-two ribbon-two-success">
                                                    <span><?php echo e($currenc->getactive()); ?></span>
                                                </div>
                                                <p class="mb-0 pt-20"><?php echo e($currenc->currency); ?>

                                            </div>
                                        <?php else: ?>
                                            <div class="box-body ribbon-box">
                                                <div class="ribbon-two ribbon-two-danger">
                                                    <span><?php echo e($currenc->getactive()); ?></span>
                                                </div>
                                                <p class="mb-0 pt-20"><?php echo e($currenc->currency); ?>

                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($currenc->abbr); ?></td>
                                    <td><?php echo e($currenc->Country); ?></td>
                                    <td><?php echo e($currenc->symbol); ?></td>

                                    <td>
                                        
                                        
                                        

                                        <div class="text-xs-right">
                                            <?php if($currenc->active == 1): ?>
                                                <a onclick="activate_cuurency('<?php echo e(route('admin.Currency.active.disactive')); ?>', '<?php echo e($currenc->id); ?>', '<?php echo e(csrf_token()); ?>')" class="btn btn-rounded btn-info mb-5  btn-danger"
                                                    title="<?php echo app('translator')->get('site.disactivate'); ?>">
                                                    <i class=" fa fa-close"></i> </span>
                                                </a>
                                                
                                            <?php else: ?>
                                                <a onclick="activate_cuurency('<?php echo e(route('admin.Currency.active.disactive')); ?>', '<?php echo e($currenc->id); ?>', '<?php echo e(csrf_token()); ?>')" class="btn btn-rounded btn-info mb-5  btn-success"
                                                    title="<?php echo app('translator')->get('site.activate'); ?>">
                                                    <i class="mdi mdi-check"></i> </span>
                                                </a>
                                            <?php endif; ?>

                                        </div>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </tbody>
                    <tfoot>
                        <tr>
                            <th><?php echo app('translator')->get('site.currency name'); ?></th>
                            <th><?php echo app('translator')->get('site.currency abbr'); ?></th>
                            <th><?php echo app('translator')->get('site.currency country'); ?></th>
                            <th><?php echo app('translator')->get('site.currency symbol'); ?></th>
                            
                            <th><?php echo app('translator')->get('site.options'); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <!-- /.box-body -->
    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#example1').DataTable({
                "order": [
                    [0, "desc"]
                ],
                responsive: true,
            });
        });
    </script>


    <script src="<?php echo e(URL::asset('assets/custome_js/activate_currency.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/setup/Currency/index.blade.php ENDPATH**/ ?>