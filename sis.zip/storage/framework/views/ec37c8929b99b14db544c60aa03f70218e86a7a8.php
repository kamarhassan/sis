<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
    'show all students',
    'register students',
    'attendance students',
    'payment students',
    'edit old payment students',
    'delete old payment students',
    'print old payment students',
    'register order delete all',
    'register order deny all',
    'register order aprrove',
    'register order delete',
    'register order deny',
    ])): ?>

    <li class="treeview   <?php echo e($prefix == getprefix('students') ? 'active' : ''); ?>     ">
        <a href="#">
            <i class="fa fa-user-circle"></i>
            <span><?php echo app('translator')->get('site.students'); ?></span>
            <span class="pull-right-container">
                <i class="fa fa-angle-right pull-right"></i>
            </span>
        </a>

        <ul class="treeview-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show all students')): ?>
                <li><a href="<?php echo e(route('admin.students.all')); ?>">
                        <i class="ti-more">
                        </i>
                        <?php echo app('translator')->get('site.all students'); ?>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('register students')): ?>
                <li><a href="<?php echo e(route('admin.students.Registration-1')); ?>" >
                        <i class="ti-more">
                        </i>
                        <?php echo app('translator')->get('site.register Student in Course'); ?>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment students')): ?>
                <li><a href="<?php echo e(route('admin.students.get_std_to_payment')); ?>" >
                        <i class="ti-more">
                        </i>
                        <?php echo app('translator')->get('site.register Student pay fee'); ?>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit old payment students', 'delete old payment students', 'print old payment students'])): ?>
                <li><a href="<?php echo e(route('admin.all-receipt')); ?>" >
                        <i class="ti-more">
                        </i>
                        <?php echo app('translator')->get('site.edit receipt and payment'); ?>
                    </a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([   'register order delete all',
            'register order deny all',
            'register order aprrove',
            'register order delete',
            'register order deny',])): ?>
                <li><a href="<?php echo e(route('admin.new.register.order')); ?>" >
                        <i class="ti-more">
                        </i>
                        <?php echo app('translator')->get('site.new registration order'); ?>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendance students')): ?>
                <li><a href="<?php echo e(route('admin.take.attendance.students')); ?>" >
                        <i class="ti-more">
                        </i>
                        <?php echo app('translator')->get('site.attendance students'); ?>
                    </a>
                </li>
            <?php endif; ?>

        </ul>
    </li>



<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/layouts/nav_bar_layouts/students.blade.php ENDPATH**/ ?>