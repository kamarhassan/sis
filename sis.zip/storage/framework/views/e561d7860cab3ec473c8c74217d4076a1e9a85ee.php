



<?php $__env->startSection('content'); ?>

    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"></h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo app('translator')->get('site.lang name'); ?> </th>
                            <th><?php echo app('translator')->get('site.abbreviation'); ?> </th>
                            <th><?php echo app('translator')->get('site.direction'); ?> </th>
                            <th><?php echo app('translator')->get('site.status '); ?> </th>
                            <th><?php echo app('translator')->get('site.options'); ?> </th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($lang)): ?>
                            <?php $__currentLoopData = $lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="Row<?php echo e($language->id); ?> " id="Row<?php echo e($language->id); ?> ">
                                    <td> <?php echo e($key + 1); ?> </td>
                                    <td> <?php echo e($language->name); ?> </td>
                                    <td> <?php echo e($language->code); ?> </td>
                                    <td> <?php echo e($language->direction); ?> </td>
                                    <td> <?php echo e($language->getActive()); ?> </td>

                                    <td>
                                        <a href="<?php echo e(route('admin.language.edit', $language->id)); ?>"
                                            class="btn  btn-warning btn-round fa fa-edit" title="<?php echo app('translator')->get('site.edit'); ?>">
                                            
                                        </a>
                                        
                                            
                                        

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>


                    </tbody>

                </table>
            </div>
        </div>
        <!-- /.box-body -->
    </div>






    <script>
        // global app configuration object
        var config = {
            routes: {
                delete: "<?php echo e(route('admin.language.delete')); ?>"
            }
        };
    </script>
    

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
    $('#example1').DataTable( {
        // "order": [ 0, 'asc' ]
        "order": [ '4', 'desc' ] // nb four is column status,
        responsive: true,
    } );
} );
    </script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/language/index.blade.php ENDPATH**/ ?>