
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .loader {
            left: 50%;
            margin-left: -4em;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="box" id="spinner_loading">
        <div class="d-flex justify-content-center text-primary">
            <div class="spinner-border" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>

    <div class="box" id="admin_table" hidden>

        
        <div class="box-body">

            <div class="table-responsive">
                <table id="example1" class="table table-hover">
                    <thead>

                        <tr>
                            <th><?php echo app('translator')->get('site.admin name'); ?></th>
                            <th><?php echo app('translator')->get('site.E-mail'); ?></th>
                            <th><?php echo app('translator')->get('site.status'); ?></th>
                            <th><?php echo app('translator')->get('site.role name'); ?></th>
                            <th><?php echo app('translator')->get('site.options'); ?></th>
                            
                        </tr>

                    </thead>
                    <tbody>
                        <?php if(isset($admin_with_role)): ?>
                            <?php $__currentLoopData = $admin_with_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="Row<?php echo e($admin_info['id']); ?>" class="bg-light mb-10 p-10 cursor_pointer hover-success">
                                    <td><?php echo e($admin_info['name']); ?></td>
                                    <td><?php echo e($admin_info['email']); ?></td>
                                    <td>
                                        <?php if($admin_info['admin_status'] == 1): ?>
                                            <span class="text-success">
                                                <?php echo app('translator')->get('site.is active'); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-danger"> <?php echo app('translator')->get('site.is not active'); ?> </span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <?php if(isset($admin_info['roles'])): ?>
                                            <?php $__currentLoopData = $admin_info['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($item['name']); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit supervisor')): ?>
                                            <a href="<?php echo e(route('admin.supervisor.edit', $admin_info['id'])); ?>" class="btn fa fa-edit"
                                                title="<?php echo app('translator')->get('site.edit'); ?>">
                                            </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete supervisor')): ?>
                                            <a title="<?php echo app('translator')->get('site.delete'); ?>" class="btn  glyphicon glyphicon-trash hover-danger"
                                                onclick="delete_by_id('<?php echo e(route('admin.supervisor.delete.supervisor')); ?>',<?php echo e($admin_info['id']); ?>,'<?php echo e(csrf_token()); ?>','<?php echo e(json_encode(swal_fire_msg())); ?>');">

                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>




    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#spinner_loading').css("display", "none");

            $('#admin_table').removeAttr('hidden');

            var table = $('#example1').DataTable({
                scrollY: "400px",
                // searching: false,
                // scrollX: true,
                scrollCollapse: true,
                paging: false,
                info: false,
                responsive: true,
                // ajax: '/test/0',

            });
        });
    </script>
    <script src="<?php echo e(URL::asset('assets\custome_js\delete.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets\custome_js\get_cours_cours_std.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/data-table.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/fixed_column_datatable.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/superviser/all.blade.php ENDPATH**/ ?>