
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="invoice printableArea" id="print">
        <div class="col-12 no-print">
            <div class="bb-1 clearFix">
                <div class="text-right pb-15">
                    
                    <button class="btn  fa fa-print  hover-success text-white text-success" title="<?php echo app('translator')->get('site.print'); ?>"
                        type="button" onclick="printarea()">
                        <span><?php echo app('translator')->get('site.print'); ?></span>
                    </button>
                    

                </div>
            </div>
        </div>
        <div class=" row">
            <div class="col-12">
                <div class="bb-1 clearFix">
                </div>
            </div>
            <div class="col-12">
                <div class="page-header">
                    <h2 class="d-inline"><span class="font-size-30"><?php echo app('translator')->get('site.receipt'); ?></span></h2>
                    <div class="pull-right text-right">
                        <h3><label><?php echo app('translator')->get('site.Release Date'); ?></label> :<?php echo e($service_repceit->created_at->format('d-m-Y')); ?>

                        </h3>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="row invoice-info">
            <div class="col-md-6 invoice-col">
                <strong><?php echo app('translator')->get('site.from'); ?></strong>
                <address>

                    
                    <strong class="text-blue bb-1 font-size-24"><?php echo e($user->name); ?></strong>
                    

                </address>
            </div>
            <div class="col-md-6 invoice-col">
                <strong><?php echo app('translator')->get('site.to'); ?></strong>
                <address>
                    <strong class="text-blue bb-1  font-size-24"><?php echo app('translator')->get('site.site name'); ?> </strong><br>
                    <strong class="d-inline">العنوان from database settings table and site name</strong><br>
                    <strong>تفاصيل email , nb pfone ...... from database settings table and site name</strong>
                </address>
            </div>
            <div class="col-sm-12 invoice-col mb-15">
                <div class="invoice-details row no-margin">
                    <div class="col-md-6 col-lg-3"><b>receipr id # <?php echo e($service_repceit['id']); ?></b></div>

                    <div class="col-md-6 col-lg-3"><b>user ID : <?php echo e($user['id']); ?></b></div>
                    <div class="col-md-6 col-lg-3"><b>services : <?php echo e($service ['id']); ?> #  <?php echo e($service ['service']); ?>  </b>
                        
                    </div>
                    <div class="col-md-6 col-lg-3"><b>amount: <?php echo e($service_repceit['amount_total']); ?> <span class="text-warning"> <?php echo e($currency['symbol']); ?> - <?php echo e($currency['abbr']); ?></span></b></div>
                </div>
            </div>
            <div class="col-sm-12 invoice-col mb-15">

            </div>
        </div>
        
    </section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_plugins/JqueryPrintArea/demo/jquery.PrintArea.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/invoice.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/custome_js/print.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/services/receipt/receipt.blade.php ENDPATH**/ ?>