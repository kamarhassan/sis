<header class="main-header">
    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top pl-30">
        <!-- Sidebar toggle button-->
        <div>
            <ul class="nav">
                <li class="btn-group nav-item">
                    <a href="#" class="waves-effect waves-light nav-link rounded svg-bt-icon" data-toggle="push-menu"
                        role="button">
                        <i class="nav-link-icon mdi mdi-menu"></i>
                    </a>
                </li>
                <ul>
                    



                </ul>
                <li class="btn-group nav-item">
                    <a href="#" data-provide="fullscreen"
                        class="waves-effect waves-light nav-link rounded svg-bt-icon" title="Full Screen">
                        <i class="nav-link-icon mdi mdi-crop-free"></i>
                    </a>
                </li>
                
                
            </ul>
        </div>



        


        <div class="nav">
            
            <li class="dropdown dropdown-language nav-item">
                <a class="dropdown-toggle nav-link" id="dropdown-flag" href="#" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                    <i class="flag-icon flag-icon-gb"></i>
                    <span class="selected-language"></span>
                </a>
                <div class="dropdown-menu" aria-labelledby="dropdown-flag">
                    <ul class="menu">
                        
                        <?php   $lang=get_active_Language() ?>
                        <?php $__currentLoopData = $lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <li>
                                <a rel="alternate" hreflang="<?php echo e($localeCode); ?>"
                                    href="<?php echo e(LaravelLocalization::getLocalizedURL($properties->code, null, [], true)); ?>">
                                    <?php echo e($properties->code); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                </div>
            </li>
        </div>

        <div class="navbar-custom-menu r-side">
            <ul class="nav navbar-nav">
                <!-- full Screen -->
                
                <!-- Notifications -->


                <!-- User Account-->
                <li class="dropdown user user-menu">
                    <a href="#" class="waves-effect waves-light rounded dropdown-toggle p-0"
                        data-toggle="dropdown" title="User">
                        <img src="<?php echo e(URL::asset(Auth::user()->photo)); ?>" alt="">
                        
                        <?php echo e(Auth::user()->name); ?>

                    </a>
                    <ul class="dropdown-menu animated flipInX">
                        <li class="user-body">
                            <a class="dropdown-item" href="<?php echo e(route('admin.profile')); ?>"><i class="ti-user text-muted mr-2"></i>
                                Profile</a>
                            
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('get.admin.logout')); ?>"><i
                                    class="ti-lock text-muted mr-2"></i> Logout</a>
                        </li>
                    </ul>
                </li>

                <?php echo $__env->make('admin.layouts.admin-notification-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                

            </ul>
        </div>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>