<!DOCTYPE html>
<html id="mode" class="loading dark" lang="<?php echo e(LaravelLocalization::getCurrentLocaleNative()); ?>"
    data-textdirection="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo e(URL::asset('assets/images/favicon.ico')); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>


    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/app-assets/css/vendors_css.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/app-assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/app-assets/css/skin_color.css')); ?>">

    <?php echo $__env->yieldContent('css'); ?>



    <?php echo toastr_css(); ?>



    <style>
        .pulse {
            position: absolute;
            top: -10px;
            right: -9px;
            height: 20px;
            width: 20px;
            z-index: 10;
            font-size: medium;
            font-weight: bold;
            color: rgb(255, 255, 255);
            border: rgb(255, 255, 255);
            border-radius: 70px;
            /* animation: pulse 1s ease-out infinite; */
        }


        /* .pulse {
            position: absolute;
            top: -10px;
            right: -9px;
            height: 20px;
            width: 20px;
            z-index: 10;
            border: 5px solid #fbff00;
            border-radius: 70px;
            animation: pulse 1s ease-out infinite;
        } */

        .marker {
            position: absolute;
            top: -0px;
            right: 10px;
            height: 20px;
            width: 20px;
            border-radius: 70px;
            background: rgb(255, 0, 0);
        }


        /* @keyframes  pulse {
            0% {
                -webkit-transform: scale(0);
                opacity: 0.0;
            }

            25% {
                -webkit-transform: scale(0.1);
                opacity: 0.1;
            }

            50% {
                -webkit-transform: scale(0.5);
                opacity: 0.3;
            }

            75% {
                -webkit-transform: scale(0.8);
                opacity: 0.5;
            }

            100% {
                -webkit-transform: scale(1);
                opacity: 0.0;
            }
        } */
    </style>
</head>




<body id="body_master" 

    class="hold-transition 
        <?php if(Session::has('mode')): ?> <?php echo e(Session::get('mode') . '-skin'); ?>

        <?php else: ?>
        dark-skin <?php endif; ?>
         sidebar-mini theme-primary fixed <?php if(get_Default_language() == 'ar'): ?> rtl <?php endif; ?>">
    
    



    <div class="wrapper">
        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.layouts.navbar_container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content-wrapper">
            <div class="container-full" style="padding:top 2%">
              

                <section class="content">
                <?php echo $__env->yieldContent('content'); ?>
                
                </section>
            </div>

        </div>
        
    </div>

    <script src="<?php echo e(URL::asset('assets/app-assets/js/vendors.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/icons/feather-icons/feather.min.js')); ?>"></script>
    
    
    
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/advanced-form-element.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/dashboard.js')); ?>"></script>
    
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/jquery-toast-plugin-master/src/jquery.toast.js')); ?>">
    </script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_plugins/iCheck/icheck.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/vendor_components/perfect-scrollbar-master/perfect-scrollbar.jquery.min.js')); ?>">
    </script>
    
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/toastr.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="<?php echo e(URL::asset('assets/custome_js/open_new_tab.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/dropzone/dropzone.js')); ?>"></script>

    <script src="<?php echo e(URL::asset('assets/custome_js/chanethememode.js')); ?>"></script>


    <?php echo $__env->yieldContent('script'); ?>
    <script src="https://js.pusher.com/7.2/pusher.min.js"></script>
    
    
    <script src="<?php echo e(URL::asset('assets/app-assets/js/template.js')); ?>"></script>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>

    <?php echo method_field('scripts'); ?>
    <script>
        // Enable pusher logging - don't include this in production
        // Pusher.logToConsole = true;

        // var pusher = new Pusher('719ad0b49c92300764ea', {
        //     cluster: 'mt1'
        // });

        // var channel = pusher.subscribe('my-channel');
        // channel.bind('my-event', function(data) {
        //   app.messages.push(JSON.stringify(data));
        // });

        // Vue application
        // const app = new Vue({
        //   el: '#app',
        //   data: {
        //     messages: [],
        //   },
        // });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/layouts/master.blade.php ENDPATH**/ ?>