<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

  
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo e(URL::asset('assets/frontend/img/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(URL::asset('assets/frontend/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
  
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(URL::asset('assets/frontend/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/frontend/vendor/icofont/icofont.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/frontend/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/frontend/vendor/animate.css/animate.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/frontend/vendor/venobox/venobox.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/frontend/vendor/owl.carousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/frontend/vendor/aos/aos.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/frontend/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo e(URL::asset('assets/frontend/css/style.css')); ?>" rel="stylesheet">


  <link rel="stylesheet" href="<?php echo e(URL::asset('assets/app-assets/css/style.css')); ?>">
  <?php echo toastr_css(); ?>
  
  
  <!-- =======================================================
  * Template Name: Company - v2.1.0
  * Template URL: https://bootstrapmade.com/company-free-html-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <!-- End Hero -->

<div id="app" style="padding-top: 2.5cm">
     <?php echo $__env->yieldContent('content'); ?>
</div>

 <!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(URL::asset('assets/frontend/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/frontend/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/frontend/vendor/jquery.easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/frontend/vendor/php-email-form/validate.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/frontend/vendor/jquery-sticky/jquery.sticky.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/frontend/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/frontend/vendor/venobox/venobox.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/frontend/vendor/waypoints/jquery.waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/frontend/vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/frontend/vendor/aos/aos.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(URL::asset('assets/frontend/js/main.js')); ?>"></script>

  <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/toastr.js')); ?>"></script>

  <?php echo $__env->yieldContent('script'); ?>

  <?php echo toastr_js(); ?>
  <?php echo app('toastr')->render(); ?>

  
    
  

  
  <script>
   document.addEventListener('contextmenu', event => event.preventDefault());
//    $(document).on({
//     "contextmenu": function (e) {
//         console.log("ctx menu button:", e.which); 

//         // Stop the context menu
//         e.preventDefault();
//     },
//     "mousedown": function(e) { 
//         console.log("normal mouse down:", e.which); 
//     },
//     "mouseup": function(e) { 
//         console.log("normal mouse up:", e.which); 
//     }
// });
  </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\sis\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>