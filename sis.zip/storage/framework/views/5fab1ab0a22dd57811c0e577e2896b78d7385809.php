
<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
  .mydivoutermulti{
    position: relative;
      background: #f90;
      width: 130px;
      height: 95px;
      float: left;
      margin-right: 15px;
  }
  .buttonoverlapmulti{
    position: absolute;
      z-index: 2;
      top: 33px;
      display: none;
      left: 19px;
      width: 92px;
  }
  .mydivoutermulti:hover .buttonoverlapmulti{ 
    display:block;
  }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="hero">
        <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

            <div class="carousel-inner" role="listbox">

                <!-- Slide 1 -->
                <div class="carousel-item active" style="background-image: url(assets/frontend/img/slide/slide-1.jpg);">
                    <div class="carousel-container">
                        <div class="carousel-content animate__animated animate__fadeInUp">
                            <h2>Welcome to <span>Company</span></h2>
                            <p>Ut velit est quam dolor ad a aliquid qui aliquid. Sequi ea ut et est quaerat sequi nihil ut
                                aliquam. Occaecati alias dolorem mollitia ut. Similique ea voluptatem. Esse doloremque
                                accusamus repellendus deleniti vel. Minus et tempore modi architecto.</p>
                            <div class="text-center"><a href="" class="btn-get-started">Read More</a></div>
                        </div>
                    </div>
                </div>

                <!-- Slide 2 -->
                <div class="carousel-item" style="background-image: url(assets/frontend/img/slide/slide-2.jpg);">
                    <div class="carousel-container">
                        <div class="carousel-content animate__animated animate__fadeInUp">
                            <h2>Lorem Ipsum Dolor</h2>
                            <p>Ut velit est quam dolor ad a aliquid qui aliquid. Sequi ea ut et est quaerat sequi nihil ut
                                aliquam. Occaecati alias dolorem mollitia ut. Similique ea voluptatem. Esse doloremque
                                accusamus repellendus deleniti vel. Minus et tempore modi architecto.</p>
                            <div class="text-center"><a href="" class="btn-get-started">Read More</a></div>
                        </div>
                    </div>
                </div>

                <!-- Slide 3 -->
                <div class="carousel-item" style="background-image: url(assets/frontend/img/slide/slide-3.jpg);">
                    <div class="carousel-container">
                        <div class="carousel-content animate__animated animate__fadeInUp">
                            <h2>Sequi ea ut et est quaerat</h2>
                            <p>Ut velit est quam dolor ad a aliquid qui aliquid. Sequi ea ut et est quaerat sequi nihil ut
                                aliquam. Occaecati alias dolorem mollitia ut. Similique ea voluptatem. Esse doloremque
                                accusamus repellendus deleniti vel. Minus et tempore modi architecto.</p>
                            <div class="text-center"><a href="" class="btn-get-started">Read More</a></div>
                        </div>
                    </div>
                </div>

            </div>

            <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon icofont-simple-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>

            <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon icofont-simple-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>

            <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

        </div>
    </section>

    <main id="main">

        <!-- ======= About Us Section ======= -->
        

        <!-- ======= Services Section ======= -->
          <section id="cours" class="services section-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2><?php echo app('translator')->get('site.cours'); ?></strong></h2>
                    <p>Laborum repudiandae omnis voluptatum consequatur mollitia ea est voluptas ut</p>
                </div>
                
            
             
              <div class="row">
                    <?php if(isset($cours)): ?>
                        <?php $__currentLoopData = $cours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 overlay" data-aos="zoom-in"
                                data-aos-delay="300">
                                <div  class="icon-box iconbox-teal">
                                    <div class="icon">
                                        <svg width="100" height="100" viewBox="0 0 600 600"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path stroke="none" stroke-width="0" fill="#f5f5f5"
                                                d="M300,566.797414625762C385.7384707136149,576.1784315230908,478.7894351017131,552.8928747891023,531.9192734346935,484.94944893311C584.6109503024035,417.5663521118492,582.489472248146,322.67544863468447,553.9536738515405,242.03673114598146C529.1557734026468,171.96086150256528,465.24506316201064,127.66468636344209,395.9583748389544,100.7403814666027C334.2173773831606,76.7482773500951,269.4350130405921,84.62216499799875,207.1952322260088,107.2889140133804C132.92018162631612,134.33871894543012,41.79353780512637,160.00259165414826,22.644507872594943,236.69541883565114C3.319112789854554,314.0945973066697,72.72355303640163,379.243833228382,124.04198916343866,440.3218312028393C172.9286146004772,498.5055451809895,224.45579914871206,558.5317968840102,300,566.797414625762">
                                            </path>
                                        </svg>
                                        <i class="bx bx-arch"></i>
                                    </div>
                                    
                                    <h4><a href="<?php echo e(route('web.cours-details',[ $item['grade']['grade'].'-'. $item['level']['level'] ,$item['id']])); ?>" title="More Details"><?php echo e($item['grade']['grade']); ?> # <?php echo e($item['level']['level']); ?></a></h4>
                                    <p>
                                        <?php if(isset($item['description'])): ?>
                                            <?php echo e($item['description']); ?>

                                        <?php endif; ?>
                                    </p>

                                    
                                </div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </div>
            </div>
        </section><!-- End Services Section -->

        <!-- ======= Portfolio Section ======= -->
        

        <!-- ======= Our Clients Section ======= -->
        

    </main>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/frontend/index.blade.php ENDPATH**/ ?>