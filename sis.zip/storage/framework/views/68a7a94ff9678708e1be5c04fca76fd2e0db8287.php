

<?php $__env->startSection('content'); ?>
    

    <div class="row">
        <div class="col-lg-12 col-12">
            <div class="box">
                <div class="box-header with-border">
                    <h4 class="box-title"></h4>
                </div>
                <!-- /.box-header -->
                <form id="new_supervaisor">
                    <?php echo csrf_field(); ?>
                    <div class="box-body">
                        <h4 class="box-title text-info"><i class="ti-user mr-15"></i>
                            <?php echo app('translator')->get('site.personal information'); ?></h4>
                        <hr class="my-15">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('site.First Name'); ?><span class="text-danger">*</span></label>
                                    <input type="text" name="first_name" class="form-control"
                                        placeholder="<?php echo app('translator')->get('site.First Name'); ?>">
                                </div>
                                <span class="text-danger" id="first_name_"> </span>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('site.Middle Name'); ?><span class="text-danger">*</span> </label>
                                    <input type="text" name="middle_name" class="form-control"
                                        placeholder="<?php echo app('translator')->get('site.Middle Name'); ?>">
                                </div>
                                <span class="text-danger" id="middle_name_"> </span>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('site.Last Name'); ?><span class="text-danger">*</span></label>
                                    <input type="text" name="last_name" class="form-control"
                                        placeholder="<?php echo app('translator')->get('site.Last Name'); ?>">
                                </div>
                                <span class="text-danger" id="last_name_"> </span>
                            </div>


                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('site.E-mail'); ?><span class="text-danger">*</span></label>
                                    <input type="text" name="email" class="form-control"
                                        placeholder="<?php echo app('translator')->get('site.E-mail'); ?>">
                                </div>
                                <span class="text-danger" id="email_"> </span>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('site.retype password'); ?><span class="text-danger">*</span></label>
                                    <input type="password" name="password" class="form-control"
                                        placeholder="<?php echo app('translator')->get('site.retype password'); ?>">
                                </div>
                                <span class="text-danger" id="password_"> </span>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('site.password'); ?><span class="text-danger">*</span></label>
                                    <input type="password" name="re_password" class="form-control"
                                        placeholder="<?php echo app('translator')->get('site.password'); ?>">
                                </div>
                                <span class="text-danger" id="re_password_"> </span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label><?php echo app('translator')->get('site.role and permission'); ?> </label>
                                <select name="role" class="form-control select2" style="width: 100%;">

                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option selected value="<?php echo e($role['name']); ?>">
                                            <?php echo e($role['name']); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <span class="text-danger" id="role_"> </span>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label><?php echo app('translator')->get('site.admin photo'); ?> </label>
                                <input type='file' name="photo" onchange="readURL(this);" />
                            </div>
                        </div>
                        <div class="col-md-4">

                            <img id="admin_image_" src="#" alt="your image" hidden />
                        </div>
                    </div>

                    <div class="box-footer">
                        
                        <a onclick="submit('<?php echo e(route('admin.supervisor.store')); ?>' ,'new_supervaisor');" type="submit"
                            class="btn btn-rounded btn-primary btn-outline">
                            <i class="ti-save-alt"></i> Save
                        </a>
                    </div>
                </form>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                $("#admin_image_").attr("hidden", false);
                reader.onload = function(e) {
                    $('#admin_image_')
                        .attr('src', e.target.result)
                        .width(150)
                        .height(150);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
    <script src="<?php echo e(URL::asset('assets/custome_js/save_and_redirect.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/select2/dist/js/select2.full.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_components/bootstrap-select/dist/js/bootstrap-select.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/app-assets/js/pages/advanced-form-element.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_plugins/input-mask/jquery.inputmask.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/assets/vendor_plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis\resources\views/admin/superviser/create.blade.php ENDPATH**/ ?>