@extends('admin.layouts.master')
@section('title')
    @lang('site.attendance students')
@endsection
@section('css')
@endsection
@section('content')
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"></h3>
            <div class="row">
                <div class="col-md-6">
                    <label>@lang('site.date') </label>
                    <form action="" id="attendance_form">
                        <div class="form-group">
                            <input name="attendance_date" class="form-control" type="date"  id="attendance_date"
                                onchange="get_students_by_date();" min="{{ $cours->act_StartDa }}"
                                max="{{ $cours->act_EndDa }}">
                                <span class="text-danger" id="attendance_date_"></span>
                        </div>
                    </form>
                    </div>
                    <div class="col-md-6">
                        <label>@lang('site.nb of hours total for cours') </label>
                        <div class="form-group">
                            <input name="total_hours" class="form-control" type="number" value=""
                                id="example-date-input">
                          
                           
                        
                        </div>
                    </div>
                </div>

            

        </div>
        <div class="box" id="spinner_loading">
            <div class="d-flex justify-content-center text-primary">
                <div class="spinner-border" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
        </div>

        {{-- <div class="box-body">
            <div class="table-responsive">
                <table id="attendance" class="table table-hover">
                    <thead>

                        <tr>
             
                            <th style="width: 50%">@lang('site.cours') </th>
                        
                            <th style="width: 50%">@lang('site.take attendance') </th>
                        </tr>
                    </thead>
                    <tbody>
                        @isset($std)
                            @foreach ($std as $key => $students)
                                <tr id="Row{{ $students['id'] }} " class="hover-success">
                                    <td class="col-md-2"> {{ $students['name'] }}</td>
                                    <td style="float: inline-end">
                                     
                                        <input size='2' type="number" name="std_id[{{ $students['id'] }}]"
                                            id="">
                                      
                                    </td>
                                </tr>
                            @endforeach
                        @endisset
                    </tbody>
                </table>
            </div>
        </div> --}}

    </div>
@endsection


@section('script')
    <script>
        // $(document).ready(function() {
        //     // $('#spinner_loading').css("display", "none");

        //     // $('#attendance').removeAttr('hidden');
        //     var table = $('#attendance').DataTable({
        //         // order: [
        //         //     [0, 'desc']
        //         // ],
        //         "ordering": false,
        //         "info": false,
        //         "searching": false,
        //         paging: false,

        //     });
        // });
    </script>
    <script src="{{ URL::asset('assets/custome_js/attendance.js') }}"></script>
    <script src="{{ URL::asset('assets/assets/vendor_components/datatable/datatables.min.js') }}"></script>
    <script src="{{ URL::asset('assets/app-assets/js/pages/data-table.js') }}"></script>
@endsection
