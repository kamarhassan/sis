<div class="box" id="spinner_loading" hidden>
    <div class="d-flex justify-content-center text-primary">
        <div class="spinner-border" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
</div>

<div class="box" id="data-report-table" hidden>


    <div class="box-body">
        <div class="table-responsive ">
            <table id="custome_data_table" style="width: 100%"   class="table table-hover display nowrap margin-top-10 w-p100">
                <thead>
                    <tr>
                        <th> id</th>
                        <th> Name</th>
                        <th> Amount</th>
                        <th> Date</th>
                        <th> Deschiption</th>

                    </tr>

                </thead>
                <tbody>

                </tbody>

            </table>
        </div>
    </div>
