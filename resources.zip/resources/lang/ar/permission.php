<?php


return [
    ################# general ##################
    'role name' => 'role',
    'add new role' => 'اضف صلاحيات',
];
